QT       += core gui widgets

CONFIG += c++17

SOURCES += \
    UserAttemptsPage.cpp \
    ViewQuizzesPage.cpp \
    attemptquizpage.cpp \
    editquizpage.cpp \
    main.cpp \
    fileutils.cpp \
    loginpage.cpp \
    profilepage.cpp \
    questioneditor.cpp \
    registrationpage.cpp \
    mainwindow.cpp \
    teachermainwindow.cpp \
    quizcreationpage.cpp \

HEADERS += \
    UserAttemptsPage.h \
    UserAttemptsPage.h \
    ViewQuizzesPage.h \
    attemptquizpage.h \
    editquizpage.h \
    fileutils.h \
    loginpage.h \
    profilepage.h \
    question.h \
    questioneditor.h \
    quiz.h \
    registrationpage.h \
    mainwindow.h \
    teachermainwindow.h \
    quizcreationpage.h \
    attemptquizpage.h \
    editquizpage.h \
    profilepage.h

FORMS += \
    UserAttemptsPage.ui \
    ViewQuizzesPage.ui \
    loginpage.ui \
    registrationpage.ui \
    mainwindow.ui \
    teachermainwindow.ui \
    quizcreationpage.ui \
    attemptquizpage.ui \
    editquizpage.ui \
    profilepage.ui


HEADERS += \
    UserAttemptsPage.h \
    ViewQuizzesPage.h \
    attemptquizpage.h \
    editquizpage.h \
    fileutils.h \
    loginpage.h \
    profilepage.h \
    question.h \
    questioneditor.h \
    quiz.h \
    registrationpage.h \
    mainwindow.h \
    teachermainwindow.h \
    quizcreationpage.h \
    attemptquizpage.h \
    editquizpage.h \
    profilepage.h

FORMS += \
    UserAttemptsPage.ui \
    ViewQuizzesPage.ui \
    loginpage.ui \
    registrationpage.ui \
    mainwindow.ui \
    teachermainwindow.ui \
    quizcreationpage.ui \
    attemptquizpage.ui \
    editquizpage.ui \
    profilepage.ui

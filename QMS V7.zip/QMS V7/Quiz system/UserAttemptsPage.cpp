#include "UserAttemptsPage.h"
#include "loginpage.h"
#include "ui_UserAttemptsPage.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QStandardItemModel>
#include <QHeaderView>
#include <QStringList>

UserAttemptsPage::UserAttemptsPage(QString userID,bool isTeacher,QWidget* parent)
    :QMainWindow(parent)
    ,ui (new Ui::UserAttemptsPage)
    ,m_userID(userID)
    ,m_isTeacher(isTeacher){
    ui->setupUi(this);
    setWindowTitle(isTeacher?"Teacher Attempts":"Your Attempts");
    if(m_isTeacher) loadTeacherQuizIDs();
    loadAttempts();
    connect(ui->backButton ,&QPushButton::clicked,this,&UserAttemptsPage::onBackBClicked);
}

UserAttemptsPage::~UserAttemptsPage(){delete ui;}

void UserAttemptsPage::loadTeacherQuizIDs(){
    QFile file("quizzes.csv");
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text)) return;
    QTextStream in(&file);
    in.readLine();
    while(!in.atEnd()){
        auto parts=in.readLine().split(',');
        if(parts.size()>=2&&parts[1].trimmed()==m_userID)
            m_teacherQuizIDs.insert(parts[0].trimmed());
    }
    file.close();
}

void UserAttemptsPage::loadAttempts(){
    auto* model=new QStandardItemModel(this);
    model->setHorizontalHeaderLabels({"QuizID","StudentID","Score","Total","Timestamp"});
    QFile file("attempts.csv");
    if(!file.open(QIODevice::ReadOnly|QIODevice::Text)){
        QMessageBox::critical(this,"Error","Cannot open attempts.csv");
        return;
    }
    QTextStream in(&file);
    in.readLine();
    while(!in.atEnd()){
        auto parts=in.readLine().split(',');
        if(parts.size()<5) continue;
        auto quizID=parts[0].trimmed();
        auto studentID=parts[1].trimmed();
        if(m_isTeacher){
            if(!m_teacherQuizIDs.contains(quizID)) continue;
        } else {
            if(studentID!=m_userID) continue;
        }
        QList<QStandardItem*> row;
        for(auto& field:parts)
            row<<new QStandardItem(field.trimmed());
        model->appendRow(row);
    }
    file.close();
    ui->attemptsTableView->setModel(model);
    ui->attemptsTableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->attemptsTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
}

void UserAttemptsPage::onBackBClicked(){
    LoginPage *lp = new LoginPage();
    lp->showMaximized();
    close();
}

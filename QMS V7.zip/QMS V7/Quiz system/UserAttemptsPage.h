#ifndef USERATTEMPTSPAGE_H
#define USERATTEMPTSPAGE_H
#include <QMainWindow>
#include <QString>
#include <QSet>

namespace Ui { class UserAttemptsPage; }

class UserAttemptsPage:public QMainWindow{ Q_OBJECT
public:
    explicit UserAttemptsPage(QString userID,bool isTeacher,QWidget* parent=nullptr);
    ~UserAttemptsPage();
private slots:
    void onBackBClicked();
private:
    Ui::UserAttemptsPage* ui;
    QString m_userID;
    bool m_isTeacher{false};
    QSet<QString> m_teacherQuizIDs;
    void loadTeacherQuizIDs();
    void loadAttempts();
};

#endif

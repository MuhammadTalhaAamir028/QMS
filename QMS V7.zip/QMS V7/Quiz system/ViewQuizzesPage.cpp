#include "viewquizzespage.h"
#include "editquizpage.h"
#include "ui_viewquizzespage.h"

#include "attemptquizpage.h"
#include "teachermainwindow.h"
#include "mainwindow.h"

#include <QFile>
#include <QTextStream>
#include <QSet>
#include <QMessageBox>

ViewQuizzesPage::ViewQuizzesPage(const QString &username, bool teacher, QWidget *parent)
    :QMainWindow(parent),ui(new Ui::ViewQuizzesPage),m_user(username),m_teacher(teacher),m_model(new QStandardItemModel(this))
{
    ui->setupUi(this);

    // Set up table: 3 columns (Quiz ID, Title, Creator)
    m_model->setColumnCount(3);
    m_model->setHeaderData(0, Qt::Horizontal, "Quiz ID");
    m_model->setHeaderData(1, Qt::Horizontal, "Title");
    m_model->setHeaderData(2, Qt::Horizontal, "Created By");

    ui->quizzesTableView->setModel(m_model);
    ui->quizzesTableView->horizontalHeader()->setStretchLastSection(true);

    // Load quizzes from CSV
    loadQuizList();

}

ViewQuizzesPage::~ViewQuizzesPage()
{
    delete ui;
}

void ViewQuizzesPage::loadQuizList()
{
    QFile file("quizzes.csv");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "Cannot open quizzes.csv");
        return;
    }

    QTextStream in(&file);
    bool firstLine = true;
    QSet<QString> seenQuizIDs;

    while(!in.atEnd()){
        QString line = in.readLine();
        if (firstLine) { firstLine = false; continue; }
        QStringList parts = line.split(',');
        //  quizID,teacherID,title,question,A,B,C,D,correct
        if (parts.size() < 5) continue;

        const QString quizID    = parts[0].trimmed();
        const QString teacherID = parts[1].trimmed();
        const QString title     = parts[2].trimmed();

        // If we're a student, we want to see ALL quizzes.
        // If we're a teacher, we can filter to only our own:
        if (m_teacher && teacherID != m_user)
            continue;

        if (seenQuizIDs.contains(quizID))
            continue;  // already added this quiz

        seenQuizIDs.insert(quizID);

        // Append a new row
        int row = m_model->rowCount();
        m_model->insertRow(row);
        m_model->setData(m_model->index(row, 0), quizID);
        m_model->setData(m_model->index(row, 1), title);
        m_model->setData(m_model->index(row, 2), teacherID);
    }
    file.close();
}

void ViewQuizzesPage::on_quizzesTableView_doubleClicked(const QModelIndex &index)
{
    if(!index.isValid()) return;

    // Get quizID from column 0 of clicked row
    QString quizID = m_model->data(m_model->index(index.row(), 0)).toString();

    // For teachers: ask if they want to edit or just preview
    if(m_teacher){
        auto choice = QMessageBox::question(this,
        "Edit or Preview",QString("Do you want to edit quiz %1? (Edit page not functional)").arg(quizID),QMessageBox::Yes | QMessageBox::No);
        if (choice == QMessageBox::Yes) {
            auto *eqp = new EditQuizPage(m_user,quizID,this);
            eqp->showMaximized();
        }

        else{
            // Preview as attempt (read-only)
            auto *aqp = new AttemptQuizPage(quizID, m_user, true);
            aqp->showMaximized();
        }
    }
    else{
        // Students always attempt
        auto *aqp = new AttemptQuizPage(quizID, m_user, false);
        aqp->showMaximized();
    }

    close();
}

void ViewQuizzesPage::on_backButton_clicked()
{
    navigateBack();
}

void ViewQuizzesPage::navigateBack()
{
    if (m_teacher) {
        auto *tmw = new TeacherMainWindow(m_user);
        tmw->showMaximized();
    } else {
        auto *mw = new MainWindow(m_user);
        mw->showMaximized();
    }
    close();
}

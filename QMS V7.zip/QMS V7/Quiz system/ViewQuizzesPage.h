#ifndef VIEWQUIZZESPAGE_H
#define VIEWQUZZESPAGE_H

#include <QMainWindow>
#include <QStandardItemModel>

QT_BEGIN_NAMESPACE
namespace Ui { class ViewQuizzesPage; }
QT_END_NAMESPACE

class ViewQuizzesPage : public QMainWindow
{
    Q_OBJECT

public:
    explicit ViewQuizzesPage(const QString &username,bool teacher=false, QWidget *parent = nullptr);
    ~ViewQuizzesPage();

private slots:
    void on_quizzesTableView_doubleClicked(const QModelIndex &index);
    void on_backButton_clicked();

private:
    Ui::ViewQuizzesPage *ui;
    QString m_user;
    bool m_teacher; //check if user is teacher or not
    QStandardItemModel *m_model;

    void loadQuizList();
    void navigateBack();
};

#endif

// attemptquizpage.cpp

#include "attemptquizpage.h"
#include "ui_attemptquizpage.h"

#include "mainwindow.h"
#include "teachermainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDateTime>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QRadioButton>
#include <QButtonGroup>

AttemptQuizPage::AttemptQuizPage(const QString &quizID, const QString &username, bool teacher,QWidget *parent)
    : QMainWindow(parent),ui(new Ui::AttemptQuizPage),m_quizID(quizID),m_user(username),m_teacher(teacher)
{
    ui->setupUi(this);

    // Display which quiz
    ui->quizIDLabel->setText("Quiz: " + m_quizID);
    loadQuestions();

    QWidget *contents = ui->scrollArea->widget();
    QVBoxLayout *lyt = qobject_cast<QVBoxLayout*>(contents->layout());
    if (!lyt) {

        lyt = new QVBoxLayout(contents);
        lyt->setContentsMargins(0,0,0,0);
        contents->setLayout(lyt);
    }


    static const char letters[] = {'A','B','C','D','E'};
    for (int i = 0; i < m_questions.size(); ++i) {
        const auto &q = m_questions[i];

        // Create a titled group box
        QGroupBox *box = new QGroupBox(
            QString("Q%1: %2").arg(i+1).arg(q.text),
            ui->scrollArea->widget()
            );
        QVBoxLayout *vbox = new QVBoxLayout(box);


        QButtonGroup *bg = new QButtonGroup(box);
        for (int opt = 0; opt < q.options.size(); ++opt) {
            if (q.options[opt].isEmpty())
                continue;
            QRadioButton *rb = new QRadioButton(
                QString("%1: %2").arg(letters[opt]).arg(q.options[opt]),box);
            bg->addButton(rb, opt);
            vbox->addWidget(rb);
        }
        m_buttonGroups.append(bg);

        lyt->addWidget(box);
    }
}

AttemptQuizPage::~AttemptQuizPage()
{
    delete ui;
}

void AttemptQuizPage::loadQuestions()
{
    QFile file("quizzes.csv");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "Cannot open quizzes.csv");
        return;
    }

    QTextStream in(&file);
    bool first = true;
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (first) { first = false; continue; }
        QStringList parts = line.split(',');
        //quizID,teacherID,title,questionText, optionA,optionB,optionC,optionD,correctAnswer
        if (parts.size() < 9) continue;
        if (parts[0] != m_quizID) continue;

        Question q;
        q.text    = parts[3].trimmed();
        q.options.clear();
        q.options << parts[4].trimmed()
                  << parts[5].trimmed()
                  << parts[6].trimmed()
                  << parts[7].trimmed();
        q.correct = parts[8].trimmed();
        m_questions.append(q);
    }
    file.close();
}

void AttemptQuizPage::on_submitButton_clicked()
{
    float total = 0, scored = 0;

    for (int i = 0; i < m_questions.size(); ++i) {
        const auto &q = m_questions[i];
        // Assuming each question is worth 1 mark by default
        total += 1.0f;

        QButtonGroup *bg = m_buttonGroups[i];
        int chosen = bg->checkedId();
        if (chosen >= 0) {
            QString letter = QString(QChar('A' + chosen));
            if (letter == q.correct)
                scored += 1.0f;
            else
                scored += 0.0f;
        }
    }

    // Record attempt
    QFile f("attempts.csv");
    if (f.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream out(&f);
        QString ts = QDateTime::currentDateTime().toString(Qt::ISODate);
        out<< m_quizID <<','<< m_user<< ','<<scored<< ','<<total<<','<<ts<< "\n";
        f.close();
    }

    QMessageBox::information(this, "Result", QString("You scored %1 out of %2").arg(scored).arg(total));
    navigateBack();
}

void AttemptQuizPage::on_cancelButton_clicked()
{
    navigateBack();
}

void AttemptQuizPage::navigateBack()
{
    if (m_teacher) {
        auto *tmw = new TeacherMainWindow(m_user);
        tmw->show();
    }

    else { //student window
        auto *mw = new MainWindow(m_user);
        mw->show();
    }
    close();
}

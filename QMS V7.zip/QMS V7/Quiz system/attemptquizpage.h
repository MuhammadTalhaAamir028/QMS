#ifndef ATTEMPTQUIZPAGE_H
#define ATTEMPTQUIZPAGE_H
#include <QMainWindow>
#include <QVector>
#include <QButtonGroup>
#include <QString>
#include "question.h"

QT_BEGIN_NAMESPACE
namespace Ui { class AttemptQuizPage; }
QT_END_NAMESPACE

class AttemptQuizPage : public QMainWindow {
    Q_OBJECT

public:
    explicit AttemptQuizPage(const QString &quizID,
                             const QString &username,
                             bool teacher = false,
                             QWidget *parent = nullptr);
    ~AttemptQuizPage();

private slots:
    void on_submitButton_clicked();
    void on_cancelButton_clicked();

private:
    Ui::AttemptQuizPage *ui;
    QString m_quizID;
    QString m_user;
    bool    m_teacher;
    QVector<Question>      m_questions;
    QVector<QButtonGroup*> m_buttonGroups;
    void loadQuestions();
    void navigateBack();
};

#endif // ATTEMPTQUIZPAGE_H

#include "EditQuizPage.h"
#include "ui_EditQuizPage.h"
#include "questioneditor.h"

#include <QFile>
#include <QTextStream>
#include <QDir>
#include <QDebug>
#include <QStringList>

EditQuizPage::EditQuizPage(QString teacherID,QString quizID,QWidget* parent)
    :QMainWindow(parent),ui(new Ui::EditQuizPage),m_teacherID(teacherID),m_quizID(quizID)
{

    // currently page not functional due to some pointer errors
    // I also could not get this page to work so if you can fix it, do let me know how
    ui->setupUi(this);
    loadQuiz();
}

EditQuizPage::~EditQuizPage(){delete ui;}

void EditQuizPage::loadQuiz(){
    Quiz quiz=loadQuizFromFile(m_quizID);
    setupUI(quiz);
}

void EditQuizPage::setupUI(const Quiz& quiz){
    ui->titleEdit->setText(quiz.title);
    ui->descriptionEdit->setPlainText(quiz.description);
    ui->questionsTable->clearContents();
    ui->questionsTable->setRowCount(quiz.questions.size());
    for(int i=0;i<quiz.questions.size();++i){
        const Question&q=quiz.questions[i];
        ui->questionsTable->setItem(i,0,new QTableWidgetItem(q.text));
        ui->questionsTable->setItem(i,1,new QTableWidgetItem(q.type));
    }
}

Quiz EditQuizPage::loadQuizFromFile(const QString& quizID){
    Quiz quiz; quiz.id=quizID;
    QFile meta("quizzes.csv");
    if(meta.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream in(&meta);
        in.readLine();
        while(!in.atEnd()){
            QStringList parts=in.readLine().split(',');
            if(parts.size()>=4&&parts[0]==quizID){
                quiz.teacherID=parts[1];
                quiz.title=parts[2];
                quiz.description=parts[3];
                break;
            }
        }
        meta.close();
    }else qWarning()<<"can't open quizzes.csv";
    QFile qfile("questions.csv");
    if(qfile.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream in(&qfile);
        in.readLine();
        while(!in.atEnd()){
            QStringList p=in.readLine().split(',');
            if(p.size()<4||p[0]!=quizID)continue;
            Question q; q.type=p[2]; q.text=p[3];
            quiz.questions.append(q);
        }
        qfile.close();
    }else qWarning()<<"can't open questions.csv";
    return quiz;
}

void EditQuizPage::onAddQuestion(){
    QuestionEditorDialog dlg(this);
    if(dlg.exec()!=QDialog::Accepted)return;
    Question q=dlg.result();
    int row=ui->questionsTable->rowCount();
    ui->questionsTable->insertRow(row);
    ui->questionsTable->setItem(row,0,new QTableWidgetItem(q.text));
    ui->questionsTable->setItem(row,1,new QTableWidgetItem(q.type));
}

void EditQuizPage::onEditQuestion(){
    int r=ui->questionsTable->currentRow();
    if(r<0)return;
    Question old; old.text=ui->questionsTable->item(r,0)->text(); old.type=ui->questionsTable->item(r,1)->text();
    QuestionEditorDialog dlg(old,this);
    if(dlg.exec()!=QDialog::Accepted)return;
    Question q=dlg.result();
    ui->questionsTable->item(r,0)->setText(q.text);
    ui->questionsTable->item(r,1)->setText(q.type);
}

void EditQuizPage::onDeleteQuestion(){
    int r=ui->questionsTable->currentRow();
    if(r<0)return; ui->questionsTable->removeRow(r);
}

void EditQuizPage::onSave(){
    QFile metaIn("quizzes.csv"); QStringList lines;
    if(metaIn.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream in(&metaIn); lines<<in.readLine(); while(!in.atEnd())lines<<in.readLine(); metaIn.close();
    }
    QFile metaOut("quizzes.csv");
    if(metaOut.open(QIODevice::WriteOnly|QIODevice::Text)){
        QTextStream out(&metaOut);
        out<<lines.first()<<"\n";
        for(int i=1;i<lines.size();++i){auto parts=lines[i].split(','); if(parts[0]==m_quizID)continue; out<<lines[i]<<"\n";}
        out<<m_quizID<<','<<m_teacherID<<','<<ui->titleEdit->text()<<','<<ui->descriptionEdit->toPlainText()<<"\n";
        metaOut.close();
    }
    QFile qIn("questions.csv"); QStringList qlines;
    if(qIn.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream in(&qIn); qlines<<in.readLine(); while(!in.atEnd())qlines<<in.readLine(); qIn.close();
    }
    QFile qOut("questions.csv");
    if(qOut.open(QIODevice::WriteOnly|QIODevice::Text)){
        QTextStream out(&qOut); out<<qlines.first()<<"\n";
        for(int i=1;i<qlines.size();++i){auto parts=qlines[i].split(','); if(parts[0]==m_quizID)continue; out<<qlines[i]<<"\n";}
        int rows=ui->questionsTable->rowCount();
        for(int i=0;i<rows;++i){QString text=ui->questionsTable->item(i,0)->text(); QString type=ui->questionsTable->item(i,1)->text(); out<<m_quizID<<','<<m_teacherID<<','<<type<<','<<text<<",,,\n";}
        qOut.close();
    }
}

void EditQuizPage::onCancel(){close();}

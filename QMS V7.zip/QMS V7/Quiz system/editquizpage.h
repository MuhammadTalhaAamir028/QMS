#ifndef EDITQUIZPAGE_H
#define EDITQUIZPAGE_H
#include <QMainWindow>
#include "Quiz.h"

namespace Ui{class EditQuizPage;}

class EditQuizPage:public QMainWindow{Q_OBJECT
public:
    explicit EditQuizPage(QString teacherID,QString quizID,QWidget* parent=nullptr);
    ~EditQuizPage();
private slots:
    void onAddQuestion();
    void onEditQuestion();
    void onDeleteQuestion();
    void onSave();
    void onCancel();
private:
    Ui::EditQuizPage* ui;
    QString m_teacherID;
    QString m_quizID;
    void loadQuiz();
    void setupUI(const Quiz& quiz);
    Quiz loadQuizFromFile(const QString& quizID);
};

#endif

#include "fileutils.h"
#include <QFile>
#include <QTextStream>
#include <QIODevice>
#include <QDebug>

void FileUtils::ensureCSV(const QString &path, const QString &content) {
    QFile file(path);
    if(!file.exists() || file.size()==0){
        qDebug()<< "Creating default"<<path;
        if(file.open(QIODevice::WriteOnly | QIODevice::Text)){
            QTextStream out(&file);
            out<<content;
            file.close();
        }
        else{
            qWarning() << "Failed to create" << path;
        }
    }
}

#ifndef FILEUTILS_H
#define FILEUTILS_H
#include <QString>

class FileUtils {
public:
    // Ensures a CSV file exists with given content (header + default entries).
    static void ensureCSV(const QString &path, const QString &content);
};

#endif

#include "loginpage.h"
#include "ui_loginpage.h"
#include "registrationpage.h"
#include "mainwindow.h"
#include "teachermainwindow.h"

#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QIODevice>
#include <QDebug>

LoginPage::LoginPage(QWidget *parent)
    : QMainWindow(parent),ui(new Ui::LoginPage)
{
    ui->setupUi(this);
}


LoginPage::~LoginPage()
{
    delete ui;
}

void LoginPage::on_loginButton_clicked(){
    const QString input = ui->usernameLineEdit->text().trimmed();
    const QString pass  = ui->passwordLineEdit->text().trimmed();
    if (input.isEmpty() || pass.isEmpty()){
        QMessageBox::warning(this, "Input Error",
                             "Please enter both your ID/name and password.");
        return;
    }
    // Student login
    QFile sfile("students.csv");
    if (sfile.open(QIODevice::ReadOnly|QIODevice::Text)){
        QTextStream in(&sfile);
        bool first=true;
        while(!in.atEnd()){
            QString line = in.readLine();
            if(first){
                first =false; continue; //skip first line
            }
            QStringList parts = line.split(',');
            for (auto &p:parts) p=p.trimmed();
            if (parts.size()<3) continue;
            if ((input==parts[0] || input == parts[1]) && pass == parts[2]) {
                MainWindow *mw = new MainWindow(parts[1]);
                mw->showMaximized();
                close();
                return;
            }
        }
    }
    else{
        QMessageBox::critical(this, "File Error",
                              "Could not open students.csv");
    }

    // Teacher login
    QFile tfile("teachers.csv");
    if (tfile.open(QIODevice::ReadOnly|QIODevice::Text)) {
        QTextStream in(&tfile);
        bool first = true;
        while (!in.atEnd()) {
            QString line = in.readLine();
            if (first) { first = false; continue; }
            QStringList parts = line.split(',');
            for (auto &p : parts) p = p.trimmed();
            if (parts.size() < 3) continue;
            if ((input == parts[0] || input == parts[1]) && pass == parts[2]) {
                TeacherMainWindow *tmw = new TeacherMainWindow(parts[1]);
                tmw->showMaximized();
                close();
                return;
            }
        }
    }

    else{
        QMessageBox::critical(this, "File Error",
                              "Could not open teachers.csv");
    }

    QMessageBox::critical(this, "Login Failed",
                          "No matching user or invalid password.");
}

void LoginPage::on_registerButton_clicked(){
    RegistrationPage *rp = new RegistrationPage();
    rp->showMaximized();
    close();
}

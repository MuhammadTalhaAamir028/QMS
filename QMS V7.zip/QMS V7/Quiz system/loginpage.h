#ifndef LOGINPAGE_H
#define LOGINPAGE_H
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class LoginPage; } //encapsulation used here
QT_END_NAMESPACE

class LoginPage : public QMainWindow{
    Q_OBJECT

public:
    explicit LoginPage(QWidget *parent = nullptr);
    ~LoginPage();

private slots:
    void on_loginButton_clicked();
    void on_registerButton_clicked();

private:
    Ui::LoginPage *ui;
};

#endif

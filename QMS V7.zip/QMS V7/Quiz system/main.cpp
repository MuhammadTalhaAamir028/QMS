#include <QApplication>
#include "fileutils.h"
#include "loginpage.h"
#include "profilepage.h"
#include <QDir>

int main(int argc, char *argv[])
{
QDir::setCurrent(QCoreApplication::applicationDirPath());
    QApplication app(argc, argv);

    FileUtils::ensureCSV("quizzes.csv","quizID,teacherID,title,questionText,optionA,optionB,optionC,optionD,correctAnswer,marks,neg");
    FileUtils::ensureCSV("students.csv","id,name,password,contact,email,age\n 2001,student1,1234,,,18");
    FileUtils::ensureCSV("teachers.csv","id,name,password,contact,email,age\n 1001,teacher1,1234,,,18");
    FileUtils::ensureCSV("attempts.csv","quizID,studentID,score,total,timestamp");
    LoginPage login;
    login.showMaximized();
    return app.exec();
}

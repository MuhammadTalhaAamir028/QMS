#include "mainwindow.h"
#include "UserAttemptsPage.h"
#include "ui_mainwindow.h"
#include "viewquizzespage.h"
#include "profilepage.h"
#include "loginpage.h"

MainWindow::MainWindow(const QString &username, QWidget *parent)
    :QMainWindow(parent),ui(new Ui::MainWindow), m_user(username)
{
    ui->setupUi(this);
    setWindowTitle(QString("Student Dashboard – %1").arg(m_user));
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_viewQuizzesButton_clicked(){
    ViewQuizzesPage *vqp = new ViewQuizzesPage(m_user, false);
    vqp->showMaximized();
    close();
}

void MainWindow::on_reviewAttemptsButton_clicked() {
    UserAttemptsPage *r = new UserAttemptsPage(m_user,false);
    r->showMaximized();
    close();
}

void MainWindow::on_viewProfileButton_clicked() {
    ProfilePage *pp = new ProfilePage(m_user, /*teacher=*/false);
    pp->showMaximized();
    close();
}

void MainWindow::on_logoutButton_clicked() {
    LoginPage *lp = new LoginPage();
    lp->showMaximized();
    close();
}

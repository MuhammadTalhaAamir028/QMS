#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow :public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(const QString &username, QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_viewQuizzesButton_clicked();
    void on_viewProfileButton_clicked();
    void on_logoutButton_clicked();
    void on_reviewAttemptsButton_clicked();

private:
    Ui::MainWindow *ui;
    QString m_user;
};

#endif

#include "profilepage.h"
#include "mainwindow.h"
#include "teachermainwindow.h"
#include "ui_profilepage.h"
#include "loginpage.h"

#include <QDir>
#include <QCoreApplication>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

ProfilePage::ProfilePage(const QString &userID,bool isTeacher,QWidget *parent)
    :QMainWindow(parent),ui(new Ui::ProfilePage),m_userID(userID),m_isTeacher(isTeacher)
{
    ui->setupUi(this);
    ui->idValue->setText(m_userID);
    ui->profValue->setText(m_isTeacher ? "Teacher" : "Student");
    loadProfile();
}

ProfilePage::~ProfilePage() {
    delete ui;
}

static QString csvwritepath(bool isTeacher){
    QDir d(QCoreApplication::applicationDirPath());
    d.cdUp();
    return d.filePath(isTeacher ? "teachers.csv" : "students.csv");
}

void ProfilePage::loadProfile(){
    const QString csv=m_isTeacher ? "teachers.csv" : "students.csv";
    QFile file(csv);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "Cannot open " + csv);
        return;
    }

    QTextStream in(&file);
    bool first = true;
    while (!in.atEnd()) {
        QString line = in.readLine();
        if (first) { first = false; continue; }
        auto parts = line.split(',');
        // fields: 0=id,1=name,2=password

        qDebug() << "Checking line:" << parts << "against userID=" << m_userID;

        if (parts.value(1).trimmed() == m_userID) {
            ui->idValue ->setText(parts.value(0).trimmed());
            ui->nameValue->setText(parts.value(1).trimmed());
            ui->contactValue->setText(parts.value(3).trimmed());
            ui->emailValue->setText(parts.value(4).trimmed());
            ui->ageValue->setValue(parts.value(5).toInt());
            break;
        }
    }
    file.close();
}

void ProfilePage::on_changePwdButton_clicked() {
    QString oldP = ui->oldPwdLineEdit->text();
    QString newP = ui->newPwdLineEdit->text();
    QString conf = ui->confPwdLineEdit->text();

    if (newP != conf)
    {
        QMessageBox::warning(this, "Mismatch", "New passwords do not match.");
        return;
    }
    saveNewPassword(oldP, newP);
}

void ProfilePage::saveNewPassword(const QString &oldPwd, const QString &newPwd)
{
   QString csv = csvwritepath(m_isTeacher);
    QFile file(csv);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::critical(this, "Error", "Cannot open " + csv);
        return;
    }

    QStringList lines;
    QTextStream in(&file);
    while (!in.atEnd()) lines << in.readLine();
    file.close();


    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        QMessageBox::critical(this, "Error", "Cannot write " + csv);
        return;
    }
    QTextStream out(&file);
    bool first = true;
    for (auto &ln : lines) {
        if (first) {
            out << ln << "\n"; first = false; continue;
        }
        auto parts = ln.split(',');
        if (parts.value(1).trimmed() == m_userID) {
            if (parts.value(2) != oldPwd) {
                QMessageBox::warning(this, "Error", "Old password is incorrect.");
                return;
            }
            parts[2] = newPwd;
            ln = parts.join(',');
        }
        out << ln << "\n";
    }
    file.close();
    QMessageBox::information(this, "Success", "Password changed.");
}

void ProfilePage::on_backProfileButton_clicked() {
    if (m_isTeacher) {
        auto *tmw = new TeacherMainWindow(m_userID);
        tmw->showMaximized();
    }
    else {
        auto *mw = new MainWindow(m_userID);
        mw->showMaximized();
    }
    close();
}

#ifndef PROFILEPAGE_H
#define PROFILEPAGE_H
#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class ProfilePage; }
QT_END_NAMESPACE

class ProfilePage : public QMainWindow {
    Q_OBJECT

public:
    explicit ProfilePage(const QString &userID, bool isTeacher = false,QWidget *parent = nullptr);
    ~ProfilePage();

private slots:
    void on_changePwdButton_clicked();
    void on_backProfileButton_clicked();

private:
    Ui::ProfilePage *ui;
    QString m_userID;
    bool    m_isTeacher;

    static QString profileCsvPath(bool isTeacher);
    void loadProfile();
    void saveNewPassword(const QString &oldPwd, const QString &newPwd);
};

#endif

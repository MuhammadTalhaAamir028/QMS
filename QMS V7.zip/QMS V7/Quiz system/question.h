#ifndef QUESTION_H
#define QUESTION_H

#include <QString>
#include <QStringList>

struct Question {
    QString type;        // MCQ or T/F
    QString text;        // The question text
    QStringList options;
    QString correct;
    float   marks;       // Marks
    float   negative;
};

#endif

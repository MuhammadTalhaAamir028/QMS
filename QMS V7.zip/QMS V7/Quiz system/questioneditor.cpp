#include "QuestionEditor.h"
#include <QVBoxLayout>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QTextEdit>
#include <QComboBox>
#include <QListWidget>
#include <QLineEdit>
#include <QDoubleSpinBox>
#include <QPushButton>
#include <QDialogButtonBox>
#include <QLabel>

QuestionEditorDialog::QuestionEditorDialog(QWidget *parent)
    : QDialog(parent)
{
    setupUi();
    onTypeChanged(typeCombo->currentText());
}

QuestionEditorDialog::QuestionEditorDialog(const Question &q, QWidget *parent)
    : QDialog(parent)
{
    setupUi();
    loadQuestion(q);
    onTypeChanged(typeCombo->currentText());
}

QuestionEditorDialog::~QuestionEditorDialog() = default;

void QuestionEditorDialog::setupUi()
{
    textEdit   = new QTextEdit;
    typeCombo  = new QComboBox;
    typeCombo->addItems({"MCQ", "TrueFalse"});
    marksSpin  = new QDoubleSpinBox;
    negSpin    = new QDoubleSpinBox;
    marksSpin->setRange(0, 100);
    negSpin->setRange(0, 100);

    optionsList    = new QListWidget;
    newOptionEdit  = new QLineEdit;
    addOptionBtn   = new QPushButton("Add Option");
    removeOptionBtn= new QPushButton("Remove Selected");

    correctCombo   = new QComboBox;

    // Form layout for core fields
    auto form = new QFormLayout;
    form->addRow("Question Text:", textEdit);
    form->addRow("Type:", typeCombo);
    form->addRow("Marks:", marksSpin);
    form->addRow("Negative Penalty:", negSpin);
    form->addRow("Correct Answer:", correctCombo);

    // MCQ options area
    auto optLayout = new QVBoxLayout;
    optLayout->addWidget(new QLabel("Options:"));
    optLayout->addWidget(optionsList);
    auto addRemLay = new QHBoxLayout;
    addRemLay->addWidget(newOptionEdit);
    addRemLay->addWidget(addOptionBtn);
    addRemLay->addWidget(removeOptionBtn);
    optLayout->addLayout(addRemLay);

    // Buttons
    auto buttons = new QDialogButtonBox;
    okBtn     = buttons->addButton("OK",  QDialogButtonBox::AcceptRole);
    cancelBtn = buttons->addButton("Cancel", QDialogButtonBox::RejectRole);

    // Main layout
    auto mainLay = new QVBoxLayout(this);
    mainLay->addLayout(form);
    mainLay->addLayout(optLayout);
    mainLay->addWidget(buttons);

    connect(typeCombo, &QComboBox::currentTextChanged,this, &QuestionEditorDialog::onTypeChanged);

    connect(addOptionBtn, &QPushButton::clicked,this, &QuestionEditorDialog::onAddOption);

    connect(removeOptionBtn, &QPushButton::clicked,this, &QuestionEditorDialog::onRemoveOption);
    connect(okBtn, &QPushButton::clicked,this,&QuestionEditorDialog::accept);

    connect(cancelBtn,&QPushButton::clicked,this, &QuestionEditorDialog::reject);
}

void QuestionEditorDialog::loadQuestion(const Question &q)
{
    m_result = q;
    textEdit->setPlainText(q.text);
    typeCombo->setCurrentText(q.type);
    marksSpin->setValue(q.marks);
    negSpin->setValue(q.negative);
    optionsList->addItems(q.options);
    correctCombo->addItems(q.options);
    correctCombo->setCurrentText(q.correct);
}

void QuestionEditorDialog::onTypeChanged(const QString &type)
{
    bool isMCQ = (type == "MCQ");
    optionsList->setVisible(isMCQ);
    newOptionEdit->setVisible(isMCQ);
    addOptionBtn->setVisible(isMCQ);
    removeOptionBtn->setVisible(isMCQ);

    if (!isMCQ){
        // True/False mode
        correctCombo->clear();
        correctCombo->addItems({"True", "False"});
    }
    else {
        QStringList opts;
        for (int i = 0; i < optionsList->count(); ++i) {
            opts << optionsList->item(i)->text();
        }
        correctCombo->clear();
        correctCombo->addItems(opts);
    }
}

void QuestionEditorDialog::onAddOption()
{
    QString opt = newOptionEdit->text().trimmed();
    if (opt.isEmpty()) return;
    optionsList->addItem(opt);
    correctCombo->addItem(opt);
    newOptionEdit->clear();
}

void QuestionEditorDialog::onRemoveOption()
{
    auto items = optionsList->selectedItems();
    for (auto *it : items) {
        correctCombo->removeItem(correctCombo->findText(it->text()));
        delete optionsList->takeItem(optionsList->row(it));
    }
}

void QuestionEditorDialog::accept()
{
    m_result.text     = textEdit->toPlainText();
    m_result.type     = typeCombo->currentText();
    m_result.marks    = marksSpin->value();
    m_result.negative = negSpin->value();

    if (m_result.type == "MCQ") {
        QStringList opts;
        for (int i = 0; i < optionsList->count(); ++i)
            opts << optionsList->item(i)->text();
        m_result.options = opts;
        m_result.correct = correctCombo->currentText();
    }
    else{
        m_result.options = {"True", "False"};
        m_result.correct = correctCombo->currentText();
    }

    QDialog::accept();
}

Question QuestionEditorDialog::result() const
{
    return m_result;
}

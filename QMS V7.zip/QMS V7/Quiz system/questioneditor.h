#ifndef QUESTIONEDITORDIALOG_H
#define QUESTIONEDITORDIALOG_H

#include <QDialog>
#include "Question.h"

class QTextEdit;
class QComboBox;
class QListWidget;
class QLineEdit;
class QDoubleSpinBox;
class QPushButton;

class QuestionEditorDialog :public QDialog{
    Q_OBJECT

public:
    explicit QuestionEditorDialog(QWidget *parent = nullptr);
    explicit QuestionEditorDialog(const Question &q, QWidget *parent = nullptr);
    ~QuestionEditorDialog();

    Question result() const;

private slots:
    void onTypeChanged(const QString &type);
    void onAddOption();
    void onRemoveOption();
    void accept() override;

private:
    void setupUi();
    void loadQuestion(const Question &q);

    // UI widgets
    QTextEdit      *textEdit;
    QComboBox      *typeCombo;
    QListWidget    *optionsList;
    QLineEdit      *newOptionEdit;
    QPushButton    *addOptionBtn;
    QPushButton    *removeOptionBtn;
    QComboBox      *correctCombo;
    QDoubleSpinBox *marksSpin;
    QDoubleSpinBox *negSpin;
    QPushButton    *okBtn;
    QPushButton    *cancelBtn;

    Question        m_result;
};

#endif

#ifndef QUIZ_H
#define QUIZ_H

#include <QString>
#include <QVector>
#include "Question.h"

struct Quiz {
    QString      id;           // Quiz Id
    QString      teacherID;
    QString      title;        // quiz title
    QString      description;  // quiz description
    QVector<Question> questions;  // all its questions
};

#endif

#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDateTime>

#include "quizcreationpage.h"
#include "ui_quizcreationpage.h"
#include "teachermainwindow.h"
#include "question.h"

QuizCreationPage::QuizCreationPage(const QString &teacherId, QWidget *parent)
    : QMainWindow(parent),ui(new Ui::QuizCreationPage),m_teacherId(teacherId)
{
    ui->setupUi(this);

    //Type combo
    ui->typeComboBox->addItems({ "MCQ", "True/False" });
    ui->correctComboBox->addItems({ "A","B","C","D" });

    // Whenever the quiz type changes, change the content of box:
    connect(ui->typeComboBox, &QComboBox::currentTextChanged,this,&QuizCreationPage::updateCorrectOptions);
}

QuizCreationPage::~QuizCreationPage() {
    delete ui;
}

void QuizCreationPage::updateCorrectOptions(const QString &type) {
    // For MCQ text inputs
    bool mcq =(type == "MCQ");
    ui->optionALineEdit->setEnabled(mcq);
    ui->optionBLineEdit->setEnabled(mcq);
    ui->optionCLineEdit->setEnabled(mcq);
    ui->optionDLineEdit->setEnabled(mcq);

    ui->correctComboBox->clear();
    if (mcq) {
        ui->correctComboBox->addItems({ "A","B","C","D" });
    }
    else {
        ui->correctComboBox->addItems({ "True","False" });
    }
}

void QuizCreationPage::on_addQuestionButton_clicked() {
    Question q;
    q.text = ui->questionTextEdit->toPlainText().trimmed();
    if (q.text.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Question cannot be empty.");
        return;
    }

    if (ui->typeComboBox->currentText() == "MCQ"){
        q.options = {
            ui->optionALineEdit->text().trimmed(),
            ui->optionBLineEdit->text().trimmed(),
            ui->optionCLineEdit->text().trimmed(),
            ui->optionDLineEdit->text().trimmed()
        };
        for (const auto &opt : std::as_const(q.options)){
            if (opt.isEmpty()) {
                QMessageBox::warning(this, "Input Error", "All four MCQ options must be filled.");
                return;
            }
        }
    }

    else{
        q.options = { "True", "False" };
    }

    q.correct  = ui->correctComboBox->currentText();
    q.marks    = ui->marksSpinBox->value();
    q.negative= ui->negativeSpinBox->value();

    m_questions.append(q);
    ui->questionsListWidget->addItem(q.text);

    // Clear
    ui->questionTextEdit->clear();
    ui->optionALineEdit->clear();
    ui->optionBLineEdit->clear();
    ui->optionCLineEdit->clear();
    ui->optionDLineEdit->clear();
}

void QuizCreationPage::on_saveQuizButton_clicked() {
    if (m_questions.isEmpty()) {
        QMessageBox::warning(this, "No Questions","Add at least one question before saving.");
        return;
    }

    QString quizID = m_teacherId + "_" + QDateTime::currentDateTime().toString("yyyyMMddHHmmss");

    QFile file("quizzes.csv");
    if (!file.open(QIODevice::Append | QIODevice::Text))
    {
        QMessageBox::critical(this, "File Error", "Cannot write to quizzes.csv");
        return;
    }
    QTextStream out(&file);

    if (file.size() == 0){
        out<<"quizID,teacherID,title,questionText,optionA,optionB,optionC,optionD,correctAnswer,mark,neg\n";
    }

    for(const auto &q : m_questions){
        QStringList cols ={ quizID,m_teacherId,ui->titleLineEdit->text().trimmed(), q.text };
        if (q.options.size()==4) {
            cols << q.options;            // A,B,C,D
        }
        else{
            cols<<"True"<<"False"     // for TF
                 << ""    << "";         // complete 4 entries
        }

        cols <<q.correct
             <<QString::number(q.marks)
             << QString::number(q.negative);
        out << cols.join(',') << "\n";
    }
    file.close();

    QMessageBox::information(this, "Quiz Saved","Quiz '" + quizID + "' saved successfully.");

    // Return to teacher dashboard
    auto *tmw = new TeacherMainWindow(m_teacherId);
    tmw->show();
    close();
}

void QuizCreationPage::on_cancelButton_clicked() {
    auto *tmw = new TeacherMainWindow(m_teacherId);
    tmw->showMaximized();
    close();
}

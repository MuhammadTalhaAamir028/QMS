#ifndef QUIZCREATIONPAGE_H
#define QUIZCREATIONPAGE_H

#include <QMainWindow>
#include <QString>
#include <QVector>
#include <question.h>

QT_BEGIN_NAMESPACE
namespace Ui { class QuizCreationPage; }
QT_END_NAMESPACE

class QuizCreationPage : public QMainWindow {
    Q_OBJECT

public:
    explicit QuizCreationPage(const QString &teacherId, QWidget *parent = nullptr);
    ~QuizCreationPage();

private slots:
    void on_addQuestionButton_clicked();
    void on_saveQuizButton_clicked();
    void on_cancelButton_clicked();
    void updateCorrectOptions(const QString &type);

private:
    Ui::QuizCreationPage *ui;
    QString m_teacherId;
    QVector<Question> m_questions;
};

#endif

#include "registrationpage.h"
#include "ui_registrationpage.h"
#include "loginpage.h"

#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QIODevice>

RegistrationPage::RegistrationPage(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::RegistrationPage)
{
    ui->setupUi(this);
    ui->professionComboBox->addItems({ "Student", "Teacher" });
}

RegistrationPage::~RegistrationPage()
{
    delete ui;
}

bool RegistrationPage::validateEmail(const QString &email) {
    return email.contains('@') && email.contains('.');
}

bool RegistrationPage::validatePassword(const QString &password) {
    bool hasAlpha = false, hasDigit = false;
    for (auto ch : password) {
        if (ch.isLetter()) hasAlpha = true;
        if (ch.isDigit())  hasDigit = true;
    }
    return password.length() >= 6 && hasAlpha && hasDigit;
}

bool RegistrationPage::userExists(const QString &csvPath,const QString &name,const QString &email)
{
    QFile f(csvPath);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text))
        return false;

    QTextStream in(&f);
    while (!in.atEnd()) {
        const QStringList parts = in.readLine().split(',');
        if (parts.size() >= 5) {
            // parts: [0]=ID, [1]=name, [2]=pass, [3]=contact, [4]=email
            if (parts[1].trimmed() == name ||
                parts[4].trimmed() == email) {
                return true;
            }
        }
    }
    return false;
}
QString RegistrationPage::generateNewID(const QString &csvPath) {
    QFile f(csvPath);
    int maxId = 0;
    if (f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&f);
        bool first = true;
        while (!in.atEnd()) {
            QString line = in.readLine();
            if (first) { first = false; continue; }
            auto parts = line.split(',');
            bool ok = false;
            int id = parts[0].toInt(&ok);
            if (ok && id > maxId) maxId = id;
        }
        f.close();
    }
    return QString::number(maxId + 1);
}

void RegistrationPage::on_registerButton_clicked()
{
    const QString name    = ui->nameLineEdit->text().trimmed();
    const QString pass    = ui->passwordLineEdit->text().trimmed();
    const QString contact = ui->contactLineEdit->text().trimmed();
    const QString email   = ui->emailLineEdit->text().trimmed();
    const int    age      = ui->ageSpinBox->value();
    const QString prof    = ui->professionComboBox->currentText();

    // Validate inputs
    if (name.isEmpty() || pass.isEmpty() || contact.isEmpty() || email.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "All fields must be filled out.");
        return;
    }
    // Determine target CSV and next ID
    QString csv = (prof == "Student") ? "students.csv" : "teachers.csv";
    QString newID = generateNewID(csv);

    if (userExists(csv, name, email)) {
        QMessageBox::information(this, "Already Registered","It looks like you already have an account.\n""Redirecting to login page.");
        auto *lp = new LoginPage();
        lp->show();
        close();
        return;}

    if (!validatePassword(pass)) {
        QMessageBox::warning(this, "Weak Password",
                             "Password must be at least 6 characters long and include both letters and digits.");
        return;
    }
    if (!validateEmail(email)) {
        QMessageBox::warning(this, "Invalid Email",
                             "Please enter a valid email address (must contain '@' and '.').");
        return;
    }


    // Append new record
    QFile file(csv);
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::critical(this, "File Error", QString("Unable to open %1 for writing.").arg(csv));
        return;
    }
    QTextStream out(&file);
    out << newID << ','
        << name  << ','
        << pass  << ','
        << contact << ','
        << email << ','
        << age   << "\n";
    file.close();

    QMessageBox::information(this, "Registered",
                             QString("%1 \"%2\" has been registered with ID %3.")
                                 .arg(prof, name, newID));

    // Return to login
    auto *lp = new LoginPage();
    lp->show();
    close();
}

void RegistrationPage::on_backButton_clicked()
{
    auto *lp = new LoginPage();
    lp->showMaximized();
    close();
}

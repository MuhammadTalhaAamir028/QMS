#ifndef REGISTRATIONPAGE_H
#define REGISTRATIONPAGE_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class RegistrationPage; }
QT_END_NAMESPACE

class RegistrationPage : public QMainWindow {
    Q_OBJECT

public:
    explicit RegistrationPage(QWidget *parent = nullptr);
    ~RegistrationPage();

private slots:
    void on_registerButton_clicked();
    void on_backButton_clicked();

private:
    Ui::RegistrationPage *ui;
    bool validateEmail(const QString &email);
    bool validatePassword(const QString &password);
    bool userExists(const QString &csvPath,const QString &name,const QString &email);
    QString generateNewID(const QString &csvPath);
};

#endif

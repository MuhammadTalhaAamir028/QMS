#include "teachermainwindow.h"
#include "ViewQuizzesPage.h"
#include "ui_teachermainwindow.h"
#include "quizcreationpage.h"
#include "UserAttemptsPage.h"
#include "profilepage.h"
#include "loginpage.h"

TeacherMainWindow::TeacherMainWindow(const QString &username, QWidget *parent)
    : QMainWindow(parent), ui(new Ui::TeacherMainWindow),m_user(username)
{
    ui->setupUi(this);
    setWindowTitle(QString("Teacher Dashboard – %1").arg(m_user));
}

TeacherMainWindow::~TeacherMainWindow() {
    delete ui;
}

void TeacherMainWindow::on_makeQuizButton_clicked() {
    QuizCreationPage *qcp = new QuizCreationPage(m_user);
    qcp->showMaximized();
    close();
}

void TeacherMainWindow::on_viewQuizzesButton_clicked() {
    ViewQuizzesPage *vqp = new ViewQuizzesPage(m_user, /*teacher=*/true);
    vqp->showMaximized();
    close();
}

void TeacherMainWindow::on_reviewAttemptsButton_clicked() {
    UserAttemptsPage *r = new UserAttemptsPage(m_user,true);
    r->showMaximized();
    close();
}

void TeacherMainWindow::on_viewProfileButton_clicked() {
    ProfilePage *pp = new ProfilePage(m_user, /*teacher=*/true);
    pp->showMaximized();
    close();
}

void TeacherMainWindow::on_logoutButton_clicked() {
    LoginPage *lp = new LoginPage();
    lp->showMaximized();
    close();
}

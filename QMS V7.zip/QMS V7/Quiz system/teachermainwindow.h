#ifndef TEACHERMAINWINDOW_H
#define TEACHERMAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class TeacherMainWindow; }
QT_END_NAMESPACE

class TeacherMainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit TeacherMainWindow(const QString &username, QWidget *parent = nullptr);
    ~TeacherMainWindow();

private slots:
    void on_makeQuizButton_clicked();
    void on_viewQuizzesButton_clicked();
    void on_reviewAttemptsButton_clicked();
    void on_viewProfileButton_clicked();
    void on_logoutButton_clicked();

private:
    Ui::TeacherMainWindow *ui;
    QString m_user;
};

#endif

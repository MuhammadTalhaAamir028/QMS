/********************************************************************************
** Form generated from reading UI file 'UserAttemptsPage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERATTEMPTSPAGE_H
#define UI_USERATTEMPTSPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UserAttemptsPage
{
public:
    QWidget *centralwidget;
    QTableView *attemptsTableView;
    QPushButton *backButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *UserAttemptsPage)
    {
        if (UserAttemptsPage->objectName().isEmpty())
            UserAttemptsPage->setObjectName("UserAttemptsPage");
        UserAttemptsPage->resize(1640, 987);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        UserAttemptsPage->setPalette(palette);
        centralwidget = new QWidget(UserAttemptsPage);
        centralwidget->setObjectName("centralwidget");
        attemptsTableView = new QTableView(centralwidget);
        attemptsTableView->setObjectName("attemptsTableView");
        attemptsTableView->setEnabled(true);
        attemptsTableView->setGeometry(QRect(200, 40, 1101, 601));
        attemptsTableView->setAutoFillBackground(false);
        attemptsTableView->setStyleSheet(QString::fromUtf8("QTableView {\n"
"    gridline-color: #6c63ff;\n"
"    background-color: #f9f7ff;\n"
"    border: 2px solid #6c63ff;\n"
"    border-radius: 8px;\n"
"    selection-background-color: #a084e8;\n"
"    selection-color: white;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"    alternate-background-color: #ece6ff;\n"
"\n"
"    /* added: make text darker and slightly bolder */\n"
"    color: #333333;\n"
"    font-weight: 500;\n"
"}\n"
"\n"
"QHeaderView::section {\n"
"    background-color: #6c63ff;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 6px;\n"
"    border: 1px solid #ddd;\n"
"    border-radius: 0px;\n"
"}\n"
"\n"
"QTableView::item {\n"
"    padding: 6px;\n"
"    border: none;\n"
"\n"
"    /* added: ensure cell text is bold and dark */\n"
"    color: #222222;\n"
"    font-weight: 600;\n"
"}\n"
"\n"
"QTableView::item:hover {\n"
"    background-color: #d3c0ff;\n"
"    color: #000;\n"
"}\n"
"\n"
"QTableView::item:selected {\n"
"    background-color: #a084e8;\n"
"    co"
                        "lor: #fff;\n"
"}\n"
""));
        backButton = new QPushButton(centralwidget);
        backButton->setObjectName("backButton");
        backButton->setGeometry(QRect(690, 690, 131, 51));
        backButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));
        UserAttemptsPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(UserAttemptsPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1640, 25));
        UserAttemptsPage->setMenuBar(menubar);
        statusbar = new QStatusBar(UserAttemptsPage);
        statusbar->setObjectName("statusbar");
        UserAttemptsPage->setStatusBar(statusbar);

        retranslateUi(UserAttemptsPage);

        QMetaObject::connectSlotsByName(UserAttemptsPage);
    } // setupUi

    void retranslateUi(QMainWindow *UserAttemptsPage)
    {
        UserAttemptsPage->setWindowTitle(QCoreApplication::translate("UserAttemptsPage", "Review Attempts", nullptr));
        backButton->setText(QCoreApplication::translate("UserAttemptsPage", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class UserAttemptsPage: public Ui_UserAttemptsPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERATTEMPTSPAGE_H

/********************************************************************************
** Form generated from reading UI file 'ViewQuizzesPage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VIEWQUIZZESPAGE_H
#define UI_VIEWQUIZZESPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ViewQuizzesPage
{
public:
    QWidget *centralwidget;
    QTableView *quizzesTableView;
    QPushButton *backButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *ViewQuizzesPage)
    {
        if (ViewQuizzesPage->objectName().isEmpty())
            ViewQuizzesPage->setObjectName("ViewQuizzesPage");
        ViewQuizzesPage->resize(1766, 1317);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        ViewQuizzesPage->setPalette(palette);
        ViewQuizzesPage->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(ViewQuizzesPage);
        centralwidget->setObjectName("centralwidget");
        quizzesTableView = new QTableView(centralwidget);
        quizzesTableView->setObjectName("quizzesTableView");
        quizzesTableView->setGeometry(QRect(225, 73, 1161, 521));
        quizzesTableView->setStyleSheet(QString::fromUtf8("QTableView {\n"
"    gridline-color: #6c63ff;\n"
"    background-color: #f9f7ff;\n"
"    border: 2px solid #6c63ff;\n"
"    border-radius: 8px;\n"
"    selection-background-color: #a084e8;\n"
"    selection-color: white;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"    alternate-background-color: #ece6ff;\n"
"\n"
"    /* added: make text darker and slightly bolder */\n"
"    color: #333333;\n"
"    font-weight: 500;\n"
"}\n"
"\n"
"QHeaderView::section {\n"
"    background-color: #6c63ff;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 6px;\n"
"    border: 1px solid #ddd;\n"
"    border-radius: 0px;\n"
"}\n"
"\n"
"QTableView::item {\n"
"    padding: 6px;\n"
"    border: none;\n"
"\n"
"    /* added: ensure cell text is bold and dark */\n"
"    color: #222222;\n"
"    font-weight: 600;\n"
"}\n"
"\n"
"QTableView::item:hover {\n"
"    background-color: #d3c0ff;\n"
"    color: #000;\n"
"}\n"
"\n"
"QTableView::item:selected {\n"
"    background-color: #a084e8;\n"
"    co"
                        "lor: #fff;\n"
"}\n"
""));
        backButton = new QPushButton(centralwidget);
        backButton->setObjectName("backButton");
        backButton->setGeometry(QRect(730, 610, 131, 51));
        backButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color:\302\240#004080;\n"
"}"));
        ViewQuizzesPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(ViewQuizzesPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1766, 25));
        ViewQuizzesPage->setMenuBar(menubar);
        statusbar = new QStatusBar(ViewQuizzesPage);
        statusbar->setObjectName("statusbar");
        ViewQuizzesPage->setStatusBar(statusbar);

        retranslateUi(ViewQuizzesPage);

        QMetaObject::connectSlotsByName(ViewQuizzesPage);
    } // setupUi

    void retranslateUi(QMainWindow *ViewQuizzesPage)
    {
        ViewQuizzesPage->setWindowTitle(QCoreApplication::translate("ViewQuizzesPage", "View Quizzes", nullptr));
        backButton->setText(QCoreApplication::translate("ViewQuizzesPage", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ViewQuizzesPage: public Ui_ViewQuizzesPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VIEWQUIZZESPAGE_H

/********************************************************************************
** Form generated from reading UI file 'attemptquizpage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ATTEMPTQUIZPAGE_H
#define UI_ATTEMPTQUIZPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AttemptQuizPage
{
public:
    QWidget *centralwidget;
    QVBoxLayout *vLayout;
    QLabel *quizIDLabel;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QHBoxLayout *hLayout;
    QPushButton *submitButton;
    QPushButton *cancelButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *AttemptQuizPage)
    {
        if (AttemptQuizPage->objectName().isEmpty())
            AttemptQuizPage->setObjectName("AttemptQuizPage");
        AttemptQuizPage->resize(1168, 685);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        AttemptQuizPage->setPalette(palette);
        centralwidget = new QWidget(AttemptQuizPage);
        centralwidget->setObjectName("centralwidget");
        vLayout = new QVBoxLayout(centralwidget);
        vLayout->setObjectName("vLayout");
        quizIDLabel = new QLabel(centralwidget);
        quizIDLabel->setObjectName("quizIDLabel");

        vLayout->addWidget(quizIDLabel);

        scrollArea = new QScrollArea(centralwidget);
        scrollArea->setObjectName("scrollArea");
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName("scrollAreaWidgetContents");
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 1144, 543));
        scrollArea->setWidget(scrollAreaWidgetContents);

        vLayout->addWidget(scrollArea);

        hLayout = new QHBoxLayout();
        hLayout->setObjectName("hLayout");
        submitButton = new QPushButton(centralwidget);
        submitButton->setObjectName("submitButton");
        submitButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));

        hLayout->addWidget(submitButton);

        cancelButton = new QPushButton(centralwidget);
        cancelButton->setObjectName("cancelButton");
        cancelButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));

        hLayout->addWidget(cancelButton);


        vLayout->addLayout(hLayout);

        AttemptQuizPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(AttemptQuizPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1168, 25));
        AttemptQuizPage->setMenuBar(menubar);
        statusbar = new QStatusBar(AttemptQuizPage);
        statusbar->setObjectName("statusbar");
        AttemptQuizPage->setStatusBar(statusbar);

        retranslateUi(AttemptQuizPage);

        QMetaObject::connectSlotsByName(AttemptQuizPage);
    } // setupUi

    void retranslateUi(QMainWindow *AttemptQuizPage)
    {
        AttemptQuizPage->setWindowTitle(QCoreApplication::translate("AttemptQuizPage", "Attempt Quiz", nullptr));
        submitButton->setText(QCoreApplication::translate("AttemptQuizPage", "Submit", nullptr));
        cancelButton->setText(QCoreApplication::translate("AttemptQuizPage", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AttemptQuizPage: public Ui_AttemptQuizPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ATTEMPTQUIZPAGE_H

/********************************************************************************
** Form generated from reading UI file 'editquizpage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITQUIZPAGE_H
#define UI_EDITQUIZPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_EditQuizPage
{
public:
    QTableWidget *questionsTable;
    QLabel *labelDescription;
    QLabel *labelTitle;
    QTextEdit *descriptionEdit;
    QLineEdit *titleEdit;
    QPushButton *editQB;
    QPushButton *delQB;
    QPushButton *addQB;
    QPushButton *save;
    QPushButton *cancelB;

    void setupUi(QWidget *EditQuizPage)
    {
        if (EditQuizPage->objectName().isEmpty())
            EditQuizPage->setObjectName("EditQuizPage");
        EditQuizPage->resize(897, 683);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        EditQuizPage->setPalette(palette);
        questionsTable = new QTableWidget(EditQuizPage);
        if (questionsTable->columnCount() < 2)
            questionsTable->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        questionsTable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        questionsTable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        questionsTable->setObjectName("questionsTable");
        questionsTable->setGeometry(QRect(120, 260, 401, 211));
        questionsTable->setStyleSheet(QString::fromUtf8("QTableWidget#questionsTable {\n"
"    background-color: #ffffff;\n"
"    border: 1px solid #ddd;\n"
"    border-radius: 8px;\n"
"    gridline-color: #eeeeee;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"    selection-background-color: #d6f0ff;\n"
"    selection-color: #000000;\n"
"    alternate-background-color: #fafafa;\n"
"    show-grid: true;\n"
"}\n"
"\n"
"QHeaderView::section {\n"
"    background-color: #f5f6f8;\n"
"    color: #2c3e50;\n"
"    font-weight: bold;\n"
"    padding: 8px;\n"
"    border: none;\n"
"    border-bottom: 1px solid #dddddd;\n"
"}\n"
"\n"
"QTableCornerButton::section {\n"
"    background-color: #f5f6f8;\n"
"    border: none;\n"
"}\n"
"\n"
"QTableWidget::item {\n"
"    padding: 10px;\n"
"    border: none;\n"
"}\n"
"\n"
"QTableWidget::item:selected {\n"
"    background-color: #d6f0ff;\n"
"    color: #000000;\n"
"    border-radius: 4px;\n"
"}\n"
"\n"
"QScrollBar:vertical {\n"
"    border: none;\n"
"    background: transparent;\n"
"    width: 10px;\n"
"    ma"
                        "rgin: 2px 0 2px 0;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical {\n"
"    background: #c1c1c1;\n"
"    min-height: 20px;\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {\n"
"    height: 0;\n"
"}\n"
"\n"
"QScrollBar:horizontal {\n"
"    border: none;\n"
"    background: transparent;\n"
"    height: 10px;\n"
"}\n"
"\n"
"QScrollBar::handle:horizontal {\n"
"    background: #c1c1c1;\n"
"    min-width: 20px;\n"
"    border-radius: 5px;\n"
"}\n"
"\n"
"QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {\n"
"    width: 0;\n"
"}\n"
""));
        questionsTable->setColumnCount(2);
        labelDescription = new QLabel(EditQuizPage);
        labelDescription->setObjectName("labelDescription");
        labelDescription->setGeometry(QRect(0, 50, 111, 61));
        labelDescription->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    color: #0078d7;\n"
"    font-size: 18px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"    font-weight: bold;\n"
"    padding: 5px;\n"
"    margin-bottom: 15px;\n"
"    background-color: transparent;\n"
"}\n"
"\n"
"QLabel:disabled {\n"
"    color: #b0b0b0;\n"
"}\n"
"\n"
"QLabel:hover {\n"
"    color: #005bb5;\n"
"    cursor: pointer;\n"
"}\n"
""));
        labelTitle = new QLabel(EditQuizPage);
        labelTitle->setObjectName("labelTitle");
        labelTitle->setGeometry(QRect(60, 10, 61, 41));
        labelTitle->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    color: #0078d7;\n"
"    font-size: 18px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"    font-weight: bold;\n"
"    padding: 5px;\n"
"    margin-bottom: 15px;\n"
"    background-color: transparent;\n"
"}\n"
"\n"
"\n"
"\n"
"QLabel:hover {\n"
"    color: #005bb5;\n"
"    cursor: pointer;\n"
"}\n"
""));
        descriptionEdit = new QTextEdit(EditQuizPage);
        descriptionEdit->setObjectName("descriptionEdit");
        descriptionEdit->setGeometry(QRect(120, 50, 261, 201));
        descriptionEdit->setStyleSheet(QString::fromUtf8("QTextEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QTextEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QTextEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        titleEdit = new QLineEdit(EditQuizPage);
        titleEdit->setObjectName("titleEdit");
        titleEdit->setGeometry(QRect(120, 10, 201, 31));
        titleEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        editQB = new QPushButton(EditQuizPage);
        editQB->setObjectName("editQB");
        editQB->setGeometry(QRect(220, 480, 91, 41));
        editQB->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));
        delQB = new QPushButton(EditQuizPage);
        delQB->setObjectName("delQB");
        delQB->setGeometry(QRect(400, 480, 121, 41));
        delQB->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));
        addQB = new QPushButton(EditQuizPage);
        addQB->setObjectName("addQB");
        addQB->setGeometry(QRect(120, 480, 91, 41));
        addQB->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));
        save = new QPushButton(EditQuizPage);
        save->setObjectName("save");
        save->setGeometry(QRect(400, 540, 121, 41));
        save->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));
        cancelB = new QPushButton(EditQuizPage);
        cancelB->setObjectName("cancelB");
        cancelB->setGeometry(QRect(220, 540, 91, 41));
        cancelB->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));

        retranslateUi(EditQuizPage);

        QMetaObject::connectSlotsByName(EditQuizPage);
    } // setupUi

    void retranslateUi(QWidget *EditQuizPage)
    {
        EditQuizPage->setWindowTitle(QCoreApplication::translate("EditQuizPage", "Edit Quiz", nullptr));
        QTableWidgetItem *___qtablewidgetitem = questionsTable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("EditQuizPage", "Question", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = questionsTable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("EditQuizPage", "Type", nullptr));
        labelDescription->setText(QCoreApplication::translate("EditQuizPage", "Description", nullptr));
        labelTitle->setText(QCoreApplication::translate("EditQuizPage", "Title", nullptr));
        editQB->setText(QCoreApplication::translate("EditQuizPage", "Edit", nullptr));
        delQB->setText(QCoreApplication::translate("EditQuizPage", "Remove", nullptr));
        addQB->setText(QCoreApplication::translate("EditQuizPage", "Add", nullptr));
        save->setText(QCoreApplication::translate("EditQuizPage", "Save Changes", nullptr));
        cancelB->setText(QCoreApplication::translate("EditQuizPage", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class EditQuizPage: public Ui_EditQuizPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITQUIZPAGE_H

/********************************************************************************
** Form generated from reading UI file 'loginpage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINPAGE_H
#define UI_LOGINPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginPage
{
public:
    QWidget *centralwidget;
    QLabel *TitleLabel;
    QLineEdit *usernameLineEdit;
    QLineEdit *passwordLineEdit;
    QPushButton *loginButton;
    QPushButton *registerButton;
    QStatusBar *statusbar;
    QMenuBar *menubar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *LoginPage)
    {
        if (LoginPage->objectName().isEmpty())
            LoginPage->setObjectName("LoginPage");
        LoginPage->resize(1199, 681);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        LoginPage->setPalette(palette);
        centralwidget = new QWidget(LoginPage);
        centralwidget->setObjectName("centralwidget");
        TitleLabel = new QLabel(centralwidget);
        TitleLabel->setObjectName("TitleLabel");
        TitleLabel->setGeometry(QRect(550, 90, 521, 71));
        QFont font;
        font.setFamilies({QString::fromUtf8("Segoe UI")});
        font.setPointSize(20);
        font.setBold(true);
        TitleLabel->setFont(font);
        TitleLabel->setStyleSheet(QString::fromUtf8("QLabel{\n"
"color: #0D1B2A; \n"
" background-color: #FDC500; \n"
"padding: 12px;\n"
"border-radius: 12px;\n"
"font-family: 'Segoe UI';\n"
"letter-spacing: 1px;\n"
"font-weight: bold;\n"
"}"));
        usernameLineEdit = new QLineEdit(centralwidget);
        usernameLineEdit->setObjectName("usernameLineEdit");
        usernameLineEdit->setGeometry(QRect(710, 330, 171, 31));
        usernameLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 4px 10px; /* reduced padding for normal height */\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        passwordLineEdit = new QLineEdit(centralwidget);
        passwordLineEdit->setObjectName("passwordLineEdit");
        passwordLineEdit->setGeometry(QRect(710, 370, 171, 31));
        passwordLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 4px 10px; /* reduced padding for normal height */\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        passwordLineEdit->setEchoMode(QLineEdit::EchoMode::Password);
        loginButton = new QPushButton(centralwidget);
        loginButton->setObjectName("loginButton");
        loginButton->setGeometry(QRect(810, 430, 71, 31));
        loginButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));
        registerButton = new QPushButton(centralwidget);
        registerButton->setObjectName("registerButton");
        registerButton->setGeometry(QRect(710, 430, 81, 31));
        registerButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"        "));
        LoginPage->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(LoginPage);
        statusbar->setObjectName("statusbar");
        LoginPage->setStatusBar(statusbar);
        menubar = new QMenuBar(LoginPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1199, 25));
        LoginPage->setMenuBar(menubar);
        toolBar = new QToolBar(LoginPage);
        toolBar->setObjectName("toolBar");
        LoginPage->addToolBar(Qt::ToolBarArea::TopToolBarArea, toolBar);

        retranslateUi(LoginPage);

        QMetaObject::connectSlotsByName(LoginPage);
    } // setupUi

    void retranslateUi(QMainWindow *LoginPage)
    {
        LoginPage->setWindowTitle(QCoreApplication::translate("LoginPage", "Quiz Management \342\200\223 Login", nullptr));
        TitleLabel->setText(QCoreApplication::translate("LoginPage", "QUIZ MANAGEMENT SYSTEM", nullptr));
        usernameLineEdit->setText(QString());
        usernameLineEdit->setPlaceholderText(QCoreApplication::translate("LoginPage", "Id or Name", nullptr));
        passwordLineEdit->setPlaceholderText(QCoreApplication::translate("LoginPage", "Password", nullptr));
        loginButton->setText(QCoreApplication::translate("LoginPage", "Login", nullptr));
        registerButton->setText(QCoreApplication::translate("LoginPage", "Register", nullptr));
        toolBar->setWindowTitle(QCoreApplication::translate("LoginPage", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginPage: public Ui_LoginPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINPAGE_H

/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *viewQuizzesButton;
    QPushButton *viewProfileButton;
    QPushButton *reviewAttemptsButton;
    QPushButton *logoutButton;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1386, 901);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        MainWindow->setPalette(palette);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        viewQuizzesButton = new QPushButton(centralwidget);
        viewQuizzesButton->setObjectName("viewQuizzesButton");
        viewQuizzesButton->setGeometry(QRect(710, 300, 171, 51));
        viewQuizzesButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        viewProfileButton = new QPushButton(centralwidget);
        viewProfileButton->setObjectName("viewProfileButton");
        viewProfileButton->setGeometry(QRect(711, 370, 171, 51));
        viewProfileButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        reviewAttemptsButton = new QPushButton(centralwidget);
        reviewAttemptsButton->setObjectName("reviewAttemptsButton");
        reviewAttemptsButton->setGeometry(QRect(710, 440, 171, 51));
        reviewAttemptsButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        logoutButton = new QPushButton(centralwidget);
        logoutButton->setObjectName("logoutButton");
        logoutButton->setGeometry(QRect(730, 550, 111, 51));
        logoutButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(480, 60, 626, 91));
        label->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font: 800 28pt \"Poppins\", \"Segoe UI\", sans-serif;\n"
"    color: #1d1d1d;\n"
"    padding: 18px 25px;\n"
"    border-radius: 18px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #ffffff, stop:1 #e0defa);\n"
"    border: 3px solid #6c63ff;\n"
"    qproperty-alignment: AlignCenter;\n"
"    letter-spacing: 3px;\n"
"    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.25);\n"
"}\n"
""));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1386, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Student Dashboard", nullptr));
        viewQuizzesButton->setText(QCoreApplication::translate("MainWindow", "VIEW QUIZZES", nullptr));
        viewProfileButton->setText(QCoreApplication::translate("MainWindow", "VIEW PROFILE", nullptr));
        reviewAttemptsButton->setText(QCoreApplication::translate("MainWindow", "VIEW ATTEMPTS", nullptr));
        logoutButton->setText(QCoreApplication::translate("MainWindow", "LOGOUT", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "STUDENT DASHBOARD", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

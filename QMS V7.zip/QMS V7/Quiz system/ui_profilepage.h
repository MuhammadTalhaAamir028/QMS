/********************************************************************************
** Form generated from reading UI file 'profilepage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROFILEPAGE_H
#define UI_PROFILEPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ProfilePage
{
public:
    QWidget *centralwidget;
    QLabel *idLabel;
    QLabel *idValue;
    QLabel *nameLabel;
    QLineEdit *nameValue;
    QLabel *contactLabel;
    QLineEdit *contactValue;
    QLabel *emailLabel;
    QLineEdit *emailValue;
    QLabel *ageLabel;
    QSpinBox *ageValue;
    QLabel *profLabel;
    QLabel *profValue;
    QLabel *oldPwdLabel;
    QLineEdit *oldPwdLineEdit;
    QLabel *newPwdLabel;
    QLineEdit *newPwdLineEdit;
    QLabel *confPwdLabel;
    QLineEdit *confPwdLineEdit;
    QPushButton *backProfileButton;
    QPushButton *changePwdButton;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *ProfilePage)
    {
        if (ProfilePage->objectName().isEmpty())
            ProfilePage->setObjectName("ProfilePage");
        ProfilePage->resize(1348, 855);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        ProfilePage->setPalette(palette);
        centralwidget = new QWidget(ProfilePage);
        centralwidget->setObjectName("centralwidget");
        idLabel = new QLabel(centralwidget);
        idLabel->setObjectName("idLabel");
        idLabel->setGeometry(QRect(620, 210, 41, 16));
        idLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        idValue = new QLabel(centralwidget);
        idValue->setObjectName("idValue");
        idValue->setGeometry(QRect(760, 211, 131, 21));
        QFont font;
        font.setPointSize(11);
        font.setBold(true);
        idValue->setFont(font);
        nameLabel = new QLabel(centralwidget);
        nameLabel->setObjectName("nameLabel");
        nameLabel->setGeometry(QRect(620, 240, 51, 16));
        nameLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        nameValue = new QLineEdit(centralwidget);
        nameValue->setObjectName("nameValue");
        nameValue->setGeometry(QRect(750, 238, 133, 31));
        nameValue->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        nameValue->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        nameValue->setReadOnly(true);
        contactLabel = new QLabel(centralwidget);
        contactLabel->setObjectName("contactLabel");
        contactLabel->setGeometry(QRect(620, 284, 61, 16));
        contactLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        contactValue = new QLineEdit(centralwidget);
        contactValue->setObjectName("contactValue");
        contactValue->setGeometry(QRect(750, 280, 133, 31));
        contactValue->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        contactValue->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        contactValue->setReadOnly(true);
        emailLabel = new QLabel(centralwidget);
        emailLabel->setObjectName("emailLabel");
        emailLabel->setGeometry(QRect(620, 320, 51, 16));
        emailLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        emailValue = new QLineEdit(centralwidget);
        emailValue->setObjectName("emailValue");
        emailValue->setGeometry(QRect(750, 320, 133, 31));
        emailValue->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        emailValue->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        emailValue->setReadOnly(true);
        ageLabel = new QLabel(centralwidget);
        ageLabel->setObjectName("ageLabel");
        ageLabel->setGeometry(QRect(620, 356, 41, 21));
        ageLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        ageValue = new QSpinBox(centralwidget);
        ageValue->setObjectName("ageValue");
        ageValue->setEnabled(true);
        ageValue->setGeometry(QRect(760, 356, 71, 31));
        ageValue->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        ageValue->setReadOnly(true);
        profLabel = new QLabel(centralwidget);
        profLabel->setObjectName("profLabel");
        profLabel->setGeometry(QRect(620, 394, 81, 16));
        profLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        profValue = new QLabel(centralwidget);
        profValue->setObjectName("profValue");
        profValue->setGeometry(QRect(760, 390, 131, 21));
        profValue->setFont(font);
        oldPwdLabel = new QLabel(centralwidget);
        oldPwdLabel->setObjectName("oldPwdLabel");
        oldPwdLabel->setGeometry(QRect(620, 424, 101, 16));
        oldPwdLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        oldPwdLineEdit = new QLineEdit(centralwidget);
        oldPwdLineEdit->setObjectName("oldPwdLineEdit");
        oldPwdLineEdit->setGeometry(QRect(750, 420, 133, 31));
        oldPwdLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        oldPwdLineEdit->setEchoMode(QLineEdit::EchoMode::Password);
        oldPwdLineEdit->setReadOnly(false);
        newPwdLabel = new QLabel(centralwidget);
        newPwdLabel->setObjectName("newPwdLabel");
        newPwdLabel->setGeometry(QRect(620, 462, 101, 16));
        newPwdLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        newPwdLineEdit = new QLineEdit(centralwidget);
        newPwdLineEdit->setObjectName("newPwdLineEdit");
        newPwdLineEdit->setGeometry(QRect(750, 458, 133, 31));
        newPwdLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        newPwdLineEdit->setEchoMode(QLineEdit::EchoMode::Password);
        newPwdLineEdit->setReadOnly(false);
        confPwdLabel = new QLabel(centralwidget);
        confPwdLabel->setObjectName("confPwdLabel");
        confPwdLabel->setGeometry(QRect(620, 498, 121, 20));
        confPwdLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;         /* Normal size */\n"
"    color: #333333;          /* Dark gray for good readability */\n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        confPwdLineEdit = new QLineEdit(centralwidget);
        confPwdLineEdit->setObjectName("confPwdLineEdit");
        confPwdLineEdit->setGeometry(QRect(750, 500, 133, 31));
        confPwdLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        confPwdLineEdit->setEchoMode(QLineEdit::EchoMode::Password);
        confPwdLineEdit->setReadOnly(false);
        backProfileButton = new QPushButton(centralwidget);
        backProfileButton->setObjectName("backProfileButton");
        backProfileButton->setGeometry(QRect(630, 560, 71, 41));
        backProfileButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #004080;\n"
"}\n"
""));
        changePwdButton = new QPushButton(centralwidget);
        changePwdButton->setObjectName("changePwdButton");
        changePwdButton->setGeometry(QRect(750, 560, 131, 41));
        changePwdButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #004080;\n"
"}\n"
""));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(520, 79, 491, 81));
        label->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font: 800 28pt \"Poppins\", \"Segoe UI\", sans-serif;\n"
"    color: #1d1d1d;\n"
"    padding: 18px 25px;\n"
"    border-radius: 18px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #ffffff, stop:1 #e0defa);\n"
"    border: 3px solid #6c63ff;\n"
"    qproperty-alignment: AlignCenter;\n"
"    letter-spacing: 3px;\n"
"    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.25);\n"
"}\n"
""));
        ProfilePage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(ProfilePage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1348, 25));
        ProfilePage->setMenuBar(menubar);
        statusbar = new QStatusBar(ProfilePage);
        statusbar->setObjectName("statusbar");
        ProfilePage->setStatusBar(statusbar);

        retranslateUi(ProfilePage);

        QMetaObject::connectSlotsByName(ProfilePage);
    } // setupUi

    void retranslateUi(QMainWindow *ProfilePage)
    {
        ProfilePage->setWindowTitle(QCoreApplication::translate("ProfilePage", "My Profile", nullptr));
        idLabel->setText(QCoreApplication::translate("ProfilePage", "ID", nullptr));
        nameLabel->setText(QCoreApplication::translate("ProfilePage", "Name", nullptr));
        nameValue->setText(QString());
        contactLabel->setText(QCoreApplication::translate("ProfilePage", "Contact", nullptr));
        contactValue->setText(QString());
        emailLabel->setText(QCoreApplication::translate("ProfilePage", "Email", nullptr));
        ageLabel->setText(QCoreApplication::translate("ProfilePage", "Age", nullptr));
        profLabel->setText(QCoreApplication::translate("ProfilePage", "Profession", nullptr));
        oldPwdLabel->setText(QCoreApplication::translate("ProfilePage", "Old Password", nullptr));
        newPwdLabel->setText(QCoreApplication::translate("ProfilePage", "New Password", nullptr));
        confPwdLabel->setText(QCoreApplication::translate("ProfilePage", "Confirm Password", nullptr));
        backProfileButton->setText(QCoreApplication::translate("ProfilePage", "Back", nullptr));
        changePwdButton->setText(QCoreApplication::translate("ProfilePage", "Change Password", nullptr));
        label->setText(QCoreApplication::translate("ProfilePage", "PROFILE PAGE", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProfilePage: public Ui_ProfilePage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROFILEPAGE_H

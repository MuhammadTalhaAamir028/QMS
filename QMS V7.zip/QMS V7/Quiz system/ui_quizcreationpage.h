/********************************************************************************
** Form generated from reading UI file 'quizcreationpage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QUIZCREATIONPAGE_H
#define UI_QUIZCREATIONPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QuizCreationPage
{
public:
    QWidget *centralwidget;
    QLabel *titleLabel;
    QLineEdit *titleLineEdit;
    QLabel *typeLabel;
    QComboBox *typeComboBox;
    QLabel *questionLabel;
    QTextEdit *questionTextEdit;
    QLineEdit *optionDLineEdit;
    QLabel *correctLabel;
    QLabel *marksLabel;
    QDoubleSpinBox *marksSpinBox;
    QLabel *negativeLabel;
    QDoubleSpinBox *negativeSpinBox;
    QPushButton *addQuestionButton;
    QPushButton *cancelButton;
    QListWidget *questionsListWidget;
    QLineEdit *optionBLineEdit;
    QLineEdit *optionALineEdit;
    QLineEdit *optionCLineEdit;
    QLabel *optionA;
    QLabel *optionB;
    QLabel *OptionC;
    QLabel *OptionD;
    QComboBox *correctComboBox;
    QPushButton *saveQuizButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *QuizCreationPage)
    {
        if (QuizCreationPage->objectName().isEmpty())
            QuizCreationPage->setObjectName("QuizCreationPage");
        QuizCreationPage->resize(1262, 862);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        QuizCreationPage->setPalette(palette);
        QuizCreationPage->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    background-color: #f4f0ff;\n"
"    border: 2px solid #6c63ff;\n"
"    border-radius: 8px;\n"
"    padding: 6px 30px 6px 10px;\n"
"    color: #333;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"    combobox-popup: 0;\n"
"}\n"
"\n"
"QComboBox:hover {\n"
"    border: 2px solid #ff00cc;\n"
"    background-color: #ede7ff;\n"
"}\n"
"\n"
"QComboBox::drop-down {\n"
"    subcontrol-origin: padding;\n"
"    subcontrol-position: top right;\n"
"    width: 24px;\n"
"    border-left: 2px solid #6c63ff;\n"
"    border-top-right-radius: 8px;\n"
"    border-bottom-right-radius: 8px;\n"
"    background-color: #a084e8;\n"
"}\n"
"\n"
"QComboBox::drop-down:hover {\n"
"    background-color: #8661ff;\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    image: url(:/icons/arrow-down.svg);  /* Replace with your custom arrow icon */\n"
"    width: 12px;\n"
"    height: 12px;\n"
"}\n"
"\n"
"QComboBox QAbstractItemView {\n"
"    background-color: #ffffff;\n"
"    border: 1px solid #6c63ff;\n"
"  "
                        "  selection-background-color: #a084e8;\n"
"    selection-color: #ffffff;\n"
"    padding: 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"    font-size: 13px;\n"
"}\n"
""));
        centralwidget = new QWidget(QuizCreationPage);
        centralwidget->setObjectName("centralwidget");
        titleLabel = new QLabel(centralwidget);
        titleLabel->setObjectName("titleLabel");
        titleLabel->setGeometry(QRect(9, 9, 71, 23));
        titleLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        titleLineEdit = new QLineEdit(centralwidget);
        titleLineEdit->setObjectName("titleLineEdit");
        titleLineEdit->setGeometry(QRect(125, 9, 155, 46));
        titleLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120,\302\240215,\302\2400.4);\n"
"}"));
        typeLabel = new QLabel(centralwidget);
        typeLabel->setObjectName("typeLabel");
        typeLabel->setGeometry(QRect(9, 61, 42, 23));
        typeLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        typeComboBox = new QComboBox(centralwidget);
        typeComboBox->setObjectName("typeComboBox");
        typeComboBox->setGeometry(QRect(125, 61, 131, 41));
        typeComboBox->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    background-color: white;\n"
"    color: black;\n"
"}\n"
"QComboBox QAbstractItemView {\n"
"    /* the list that pops down */\n"
"    background-color: white;\n"
"    color: black;\n"
"    selection-background-color: #6c63ff;\n"
"    selection-color: white;\n"
"}\n"
""));
        questionLabel = new QLabel(centralwidget);
        questionLabel->setObjectName("questionLabel");
        questionLabel->setGeometry(QRect(9, 110, 70, 23));
        questionLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        questionTextEdit = new QTextEdit(centralwidget);
        questionTextEdit->setObjectName("questionTextEdit");
        questionTextEdit->setGeometry(QRect(125, 110, 671, 121));
        questionTextEdit->setStyleSheet(QString::fromUtf8("QTextEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QTextEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QTextEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}"));
        optionDLineEdit = new QLineEdit(centralwidget);
        optionDLineEdit->setObjectName("optionDLineEdit");
        optionDLineEdit->setGeometry(QRect(125, 398, 155, 46));
        optionDLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120,\302\240215,\302\2400.4);\n"
"}"));
        correctLabel = new QLabel(centralwidget);
        correctLabel->setObjectName("correctLabel");
        correctLabel->setGeometry(QRect(9, 450, 108, 23));
        correctLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        marksLabel = new QLabel(centralwidget);
        marksLabel->setObjectName("marksLabel");
        marksLabel->setGeometry(QRect(9, 500, 52, 23));
        marksLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        marksSpinBox = new QDoubleSpinBox(centralwidget);
        marksSpinBox->setObjectName("marksSpinBox");
        marksSpinBox->setGeometry(QRect(125, 500, 81, 31));
        marksSpinBox->setStyleSheet(QString::fromUtf8(""));
        negativeLabel = new QLabel(centralwidget);
        negativeLabel->setObjectName("negativeLabel");
        negativeLabel->setGeometry(QRect(9, 540, 110, 23));
        negativeLabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        negativeSpinBox = new QDoubleSpinBox(centralwidget);
        negativeSpinBox->setObjectName("negativeSpinBox");
        negativeSpinBox->setGeometry(QRect(125, 540, 81, 31));
        negativeSpinBox->setStyleSheet(QString::fromUtf8(""));
        addQuestionButton = new QPushButton(centralwidget);
        addQuestionButton->setObjectName("addQuestionButton");
        addQuestionButton->setGeometry(QRect(320, 520, 161, 51));
        addQuestionButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #004080;\n"
"}"));
        cancelButton = new QPushButton(centralwidget);
        cancelButton->setObjectName("cancelButton");
        cancelButton->setGeometry(QRect(130, 720, 111, 41));
        cancelButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #004080;\n"
"}"));
        questionsListWidget = new QListWidget(centralwidget);
        questionsListWidget->setObjectName("questionsListWidget");
        questionsListWidget->setGeometry(QRect(130, 610, 661, 101));
        questionsListWidget->setStyleSheet(QString::fromUtf8("QListWidget {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QListWidget:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QListWidget:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}"));
        optionBLineEdit = new QLineEdit(centralwidget);
        optionBLineEdit->setObjectName("optionBLineEdit");
        optionBLineEdit->setGeometry(QRect(125, 294, 155, 46));
        optionBLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120,\302\240215,\302\2400.4);\n"
"}"));
        optionALineEdit = new QLineEdit(centralwidget);
        optionALineEdit->setObjectName("optionALineEdit");
        optionALineEdit->setGeometry(QRect(125, 242, 155, 46));
        optionALineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120,\302\240215,\302\2400.4);\n"
"}"));
        optionCLineEdit = new QLineEdit(centralwidget);
        optionCLineEdit->setObjectName("optionCLineEdit");
        optionCLineEdit->setGeometry(QRect(125, 346, 155, 46));
        optionCLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding: 10px 14px;\n"
"    font-size: 15px;\n"
"    color: #2b2b2b;\n"
"    font-weight: 500;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120,\302\240215,\302\2400.4);\n"
"}"));
        optionA = new QLabel(centralwidget);
        optionA->setObjectName("optionA");
        optionA->setGeometry(QRect(9, 242, 84, 23));
        optionA->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        optionB = new QLabel(centralwidget);
        optionB->setObjectName("optionB");
        optionB->setGeometry(QRect(9, 294, 77, 23));
        optionB->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        OptionC = new QLabel(centralwidget);
        OptionC->setObjectName("OptionC");
        OptionC->setGeometry(QRect(9, 346, 78, 23));
        OptionC->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        OptionD = new QLabel(centralwidget);
        OptionD->setObjectName("OptionD");
        OptionD->setGeometry(QRect(9, 398, 79, 23));
        OptionD->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        correctComboBox = new QComboBox(centralwidget);
        correctComboBox->setObjectName("correctComboBox");
        correctComboBox->setGeometry(QRect(125, 450, 131, 41));
        correctComboBox->setAutoFillBackground(false);
        correctComboBox->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    background-color: white;\n"
"    color: black;\n"
"}\n"
"QComboBox QAbstractItemView {\n"
"    /* the list that pops down */\n"
"    background-color: white;\n"
"    color: black;\n"
"    selection-background-color: #6c63ff;\n"
"    selection-color: white;\n"
"}\n"
""));
        saveQuizButton = new QPushButton(centralwidget);
        saveQuizButton->setObjectName("saveQuizButton");
        saveQuizButton->setGeometry(QRect(270, 720, 131, 41));
        saveQuizButton->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #004080;\n"
"}"));
        QuizCreationPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(QuizCreationPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1262, 25));
        QuizCreationPage->setMenuBar(menubar);
        statusbar = new QStatusBar(QuizCreationPage);
        statusbar->setObjectName("statusbar");
        QuizCreationPage->setStatusBar(statusbar);

        retranslateUi(QuizCreationPage);

        QMetaObject::connectSlotsByName(QuizCreationPage);
    } // setupUi

    void retranslateUi(QMainWindow *QuizCreationPage)
    {
        QuizCreationPage->setWindowTitle(QCoreApplication::translate("QuizCreationPage", "Create Quiz", nullptr));
        titleLabel->setText(QCoreApplication::translate("QuizCreationPage", "Quiz Title", nullptr));
        typeLabel->setText(QCoreApplication::translate("QuizCreationPage", "Type", nullptr));
        questionLabel->setText(QCoreApplication::translate("QuizCreationPage", "Question", nullptr));
        correctLabel->setText(QCoreApplication::translate("QuizCreationPage", "Correct Answer", nullptr));
        marksLabel->setText(QCoreApplication::translate("QuizCreationPage", "Marks", nullptr));
        negativeLabel->setText(QCoreApplication::translate("QuizCreationPage", "Negative Marks", nullptr));
        addQuestionButton->setText(QCoreApplication::translate("QuizCreationPage", "Save Question", nullptr));
        cancelButton->setText(QCoreApplication::translate("QuizCreationPage", "Cancel", nullptr));
        optionA->setText(QCoreApplication::translate("QuizCreationPage", "Options (A)", nullptr));
        optionB->setText(QCoreApplication::translate("QuizCreationPage", "Option (B)", nullptr));
        OptionC->setText(QCoreApplication::translate("QuizCreationPage", "Option (C)", nullptr));
        OptionD->setText(QCoreApplication::translate("QuizCreationPage", "Option (D)", nullptr));
        saveQuizButton->setText(QCoreApplication::translate("QuizCreationPage", "Save Quiz", nullptr));
    } // retranslateUi

};

namespace Ui {
    class QuizCreationPage: public Ui_QuizCreationPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QUIZCREATIONPAGE_H

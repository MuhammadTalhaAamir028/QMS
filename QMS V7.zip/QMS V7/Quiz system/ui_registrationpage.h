/********************************************************************************
** Form generated from reading UI file 'registrationpage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTRATIONPAGE_H
#define UI_REGISTRATIONPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_RegistrationPage
{
public:
    QWidget *centralwidget;
    QLabel *nameLabel;
    QLineEdit *nameLineEdit;
    QLabel *passwordLabel;
    QLineEdit *passwordLineEdit;
    QLabel *contactLabel;
    QLineEdit *contactLineEdit;
    QLabel *emailLabel;
    QLineEdit *emailLineEdit;
    QLabel *ageLabel;
    QSpinBox *ageSpinBox;
    QLabel *professionLabel;
    QComboBox *professionComboBox;
    QPushButton *registerButton;
    QPushButton *backButton;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *RegistrationPage)
    {
        if (RegistrationPage->objectName().isEmpty())
            RegistrationPage->setObjectName("RegistrationPage");
        RegistrationPage->resize(1025, 684);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        RegistrationPage->setPalette(palette);
        centralwidget = new QWidget(RegistrationPage);
        centralwidget->setObjectName("centralwidget");
        nameLabel = new QLabel(centralwidget);
        nameLabel->setObjectName("nameLabel");
        nameLabel->setGeometry(QRect(590, 249, 61, 16));
        nameLabel->setStyleSheet(QString::fromUtf8("\n"
"QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        nameLineEdit = new QLineEdit(centralwidget);
        nameLineEdit->setObjectName("nameLineEdit");
        nameLineEdit->setGeometry(QRect(680, 249, 133, 31));
        nameLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        passwordLabel = new QLabel(centralwidget);
        passwordLabel->setObjectName("passwordLabel");
        passwordLabel->setGeometry(QRect(590, 287, 71, 16));
        passwordLabel->setStyleSheet(QString::fromUtf8("\n"
"QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        passwordLineEdit = new QLineEdit(centralwidget);
        passwordLineEdit->setObjectName("passwordLineEdit");
        passwordLineEdit->setGeometry(QRect(680, 287, 133, 31));
        passwordLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        passwordLineEdit->setEchoMode(QLineEdit::EchoMode::Password);
        contactLabel = new QLabel(centralwidget);
        contactLabel->setObjectName("contactLabel");
        contactLabel->setGeometry(QRect(590, 325, 61, 16));
        contactLabel->setStyleSheet(QString::fromUtf8("\n"
"QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        contactLineEdit = new QLineEdit(centralwidget);
        contactLineEdit->setObjectName("contactLineEdit");
        contactLineEdit->setGeometry(QRect(680, 325, 133, 31));
        contactLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        emailLabel = new QLabel(centralwidget);
        emailLabel->setObjectName("emailLabel");
        emailLabel->setGeometry(QRect(590, 363, 51, 16));
        emailLabel->setStyleSheet(QString::fromUtf8("\n"
"QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        emailLineEdit = new QLineEdit(centralwidget);
        emailLineEdit->setObjectName("emailLineEdit");
        emailLineEdit->setGeometry(QRect(680, 363, 133, 31));
        emailLineEdit->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: rgba(255, 255, 255, 0.85);\n"
"    border: 2px solid transparent;\n"
"    border-radius: 10px;\n"
"    padding-top: 6px;   /* reduced from 10px */\n"
"    padding-bottom: 6px;\n"
"    padding-left: 14px;\n"
"    padding-right: 14px;\n"
"    font-size: 15px;\n"
"    font-weight: 500;\n"
"    font-family: \"Segoe UI\", sans-serif;\n"
"    color: #2b2b2b;\n"
"    line-height: 1.2;\n"
"    transition: all 0.3s ease-in-out;\n"
"    outline: none;\n"
"    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);\n"
"}\n"
"\n"
"QLineEdit:hover {\n"
"    background-color: rgba(255, 255, 255, 0.95);\n"
"    border: 2px solid #d0d0d0;\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #0078d7;\n"
"    color: #000;\n"
"    box-shadow: 0 0 5px rgba(0, 120, 215, 0.4);\n"
"}\n"
""));
        ageLabel = new QLabel(centralwidget);
        ageLabel->setObjectName("ageLabel");
        ageLabel->setGeometry(QRect(590, 401, 41, 21));
        ageLabel->setStyleSheet(QString::fromUtf8("\n"
"QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        ageSpinBox = new QSpinBox(centralwidget);
        ageSpinBox->setObjectName("ageSpinBox");
        ageSpinBox->setGeometry(QRect(680, 401, 61, 31));
        ageSpinBox->setStyleSheet(QString::fromUtf8(""));
        professionLabel = new QLabel(centralwidget);
        professionLabel->setObjectName("professionLabel");
        professionLabel->setGeometry(QRect(590, 440, 81, 16));
        professionLabel->setStyleSheet(QString::fromUtf8("\n"
"QLabel {\n"
"    font-size: 14px;       \n"
"    color: #333333;        \n"
"    padding: 2px 4px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}"));
        professionComboBox = new QComboBox(centralwidget);
        professionComboBox->setObjectName("professionComboBox");
        professionComboBox->setGeometry(QRect(680, 440, 131, 21));
        professionComboBox->setStyleSheet(QString::fromUtf8(""));
        registerButton = new QPushButton(centralwidget);
        registerButton->setObjectName("registerButton");
        registerButton->setGeometry(QRect(740, 490, 75, 31));
        registerButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color:\302\240#004080;\n"
"}"));
        backButton = new QPushButton(centralwidget);
        backButton->setObjectName("backButton");
        backButton->setGeometry(QRect(600, 490, 75, 31));
        backButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color:\302\240#004080;\n"
"}"));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(410, 50, 571, 81));
        label->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font: 800 28pt \"Poppins\", \"Segoe UI\", sans-serif;\n"
"    color: #1d1d1d;\n"
"    padding: 18px 25px;\n"
"    border-radius: 18px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #ffffff, stop:1 #e0defa);\n"
"    border: 3px solid #6c63ff;\n"
"    qproperty-alignment: AlignCenter;\n"
"    letter-spacing: 3px;\n"
"    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.25);\n"
"}\n"
""));
        RegistrationPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(RegistrationPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1025, 25));
        RegistrationPage->setMenuBar(menubar);
        statusbar = new QStatusBar(RegistrationPage);
        statusbar->setObjectName("statusbar");
        RegistrationPage->setStatusBar(statusbar);

        retranslateUi(RegistrationPage);

        QMetaObject::connectSlotsByName(RegistrationPage);
    } // setupUi

    void retranslateUi(QMainWindow *RegistrationPage)
    {
        RegistrationPage->setWindowTitle(QCoreApplication::translate("RegistrationPage", "Quiz Management \342\200\223 Registration", nullptr));
        nameLabel->setText(QCoreApplication::translate("RegistrationPage", "Name", nullptr));
        nameLineEdit->setText(QString());
        passwordLabel->setText(QCoreApplication::translate("RegistrationPage", "Password", nullptr));
        passwordLineEdit->setText(QString());
        contactLabel->setText(QCoreApplication::translate("RegistrationPage", "Contact", nullptr));
        emailLabel->setText(QCoreApplication::translate("RegistrationPage", "Email", nullptr));
        emailLineEdit->setText(QString());
        ageLabel->setText(QCoreApplication::translate("RegistrationPage", "Age", nullptr));
        professionLabel->setText(QCoreApplication::translate("RegistrationPage", "Profession", nullptr));
        registerButton->setText(QCoreApplication::translate("RegistrationPage", "Register", nullptr));
        backButton->setText(QCoreApplication::translate("RegistrationPage", "Back", nullptr));
        label->setText(QCoreApplication::translate("RegistrationPage", "REGISTRATION PAGE", nullptr));
    } // retranslateUi

};

namespace Ui {
    class RegistrationPage: public Ui_RegistrationPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTRATIONPAGE_H

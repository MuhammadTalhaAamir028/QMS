/********************************************************************************
** Form generated from reading UI file 'reviewattemptspage.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REVIEWATTEMPTSPAGE_H
#define UI_REVIEWATTEMPTSPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ReviewAttemptsPage
{
public:
    QWidget *centralwidget;
    QTableView *attemptsTableView;
    QPushButton *backButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *ReviewAttemptsPage)
    {
        if (ReviewAttemptsPage->objectName().isEmpty())
            ReviewAttemptsPage->setObjectName("ReviewAttemptsPage");
        ReviewAttemptsPage->resize(1008, 658);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        ReviewAttemptsPage->setPalette(palette);
        centralwidget = new QWidget(ReviewAttemptsPage);
        centralwidget->setObjectName("centralwidget");
        attemptsTableView = new QTableView(centralwidget);
        attemptsTableView->setObjectName("attemptsTableView");
        attemptsTableView->setEnabled(true);
        attemptsTableView->setGeometry(QRect(9, 9, 256, 192));
        attemptsTableView->setAutoFillBackground(false);
        attemptsTableView->setStyleSheet(QString::fromUtf8("QTableView {\n"
"    gridline-color: #6c63ff;\n"
"    background-color: #f9f7ff;\n"
"    border: 2px solid #6c63ff;\n"
"    border-radius: 8px;\n"
"    selection-background-color: #a084e8;\n"
"    selection-color: white;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"    alternate-background-color: #ece6ff;\n"
"}\n"
"\n"
"QHeaderView::section {\n"
"    background-color: #6c63ff;\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    padding: 6px;\n"
"    border: 1px solid #ddd;\n"
"    border-radius: 0px;\n"
"}\n"
"\n"
"QTableView::item {\n"
"    padding: 6px;\n"
"    border: none;\n"
"}\n"
"\n"
"QTableView::item:hover {\n"
"    background-color: #d3c0ff;\n"
"    color: #000;\n"
"}\n"
"\n"
"QTableView::item:selected {\n"
"    background-color: #a084e8;\n"
"    color: #fff;\n"
"}\n"
""));
        backButton = new QPushButton(centralwidget);
        backButton->setObjectName("backButton");
        backButton->setGeometry(QRect(20, 210, 81, 31));
        backButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: #007bff;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 6px 12px;\n"
"    border: none;\n"
"    font-size: 14px;\n"
"    font-family: 'Segoe UI', sans-serif;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #0056b3;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color:\302\240#004080;\n"
"}"));
        ReviewAttemptsPage->setCentralWidget(centralwidget);
        menubar = new QMenuBar(ReviewAttemptsPage);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1008, 22));
        ReviewAttemptsPage->setMenuBar(menubar);
        statusbar = new QStatusBar(ReviewAttemptsPage);
        statusbar->setObjectName("statusbar");
        ReviewAttemptsPage->setStatusBar(statusbar);

        retranslateUi(ReviewAttemptsPage);

        QMetaObject::connectSlotsByName(ReviewAttemptsPage);
    } // setupUi

    void retranslateUi(QMainWindow *ReviewAttemptsPage)
    {
        ReviewAttemptsPage->setWindowTitle(QCoreApplication::translate("ReviewAttemptsPage", "Review Attempts", nullptr));
        backButton->setText(QCoreApplication::translate("ReviewAttemptsPage", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ReviewAttemptsPage: public Ui_ReviewAttemptsPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REVIEWATTEMPTSPAGE_H

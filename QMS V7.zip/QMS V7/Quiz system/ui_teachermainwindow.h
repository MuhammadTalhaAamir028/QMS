/********************************************************************************
** Form generated from reading UI file 'teachermainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEACHERMAINWINDOW_H
#define UI_TEACHERMAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TeacherMainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *makeQuizButton;
    QPushButton *viewQuizzesButton;
    QPushButton *reviewAttemptsButton;
    QPushButton *viewProfileButton;
    QPushButton *logoutButton;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *TeacherMainWindow)
    {
        if (TeacherMainWindow->objectName().isEmpty())
            TeacherMainWindow->setObjectName("TeacherMainWindow");
        TeacherMainWindow->resize(1229, 697);
        QPalette palette;
        QBrush brush(QColor(199, 199, 194, 255));
        brush.setStyle(Qt::BrushStyle::SolidPattern);
        palette.setBrush(QPalette::ColorGroup::Active, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Inactive, QPalette::ColorRole::Window, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Base, brush);
        palette.setBrush(QPalette::ColorGroup::Disabled, QPalette::ColorRole::Window, brush);
        TeacherMainWindow->setPalette(palette);
        centralwidget = new QWidget(TeacherMainWindow);
        centralwidget->setObjectName("centralwidget");
        makeQuizButton = new QPushButton(centralwidget);
        makeQuizButton->setObjectName("makeQuizButton");
        makeQuizButton->setGeometry(QRect(680, 260, 191, 41));
        makeQuizButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        viewQuizzesButton = new QPushButton(centralwidget);
        viewQuizzesButton->setObjectName("viewQuizzesButton");
        viewQuizzesButton->setGeometry(QRect(680, 320, 191, 41));
        viewQuizzesButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        reviewAttemptsButton = new QPushButton(centralwidget);
        reviewAttemptsButton->setObjectName("reviewAttemptsButton");
        reviewAttemptsButton->setGeometry(QRect(680, 380, 191, 41));
        reviewAttemptsButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        viewProfileButton = new QPushButton(centralwidget);
        viewProfileButton->setObjectName("viewProfileButton");
        viewProfileButton->setGeometry(QRect(680, 440, 191, 41));
        viewProfileButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        logoutButton = new QPushButton(centralwidget);
        logoutButton->setObjectName("logoutButton");
        logoutButton->setGeometry(QRect(720, 510, 111, 41));
        logoutButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #6c63ff, stop:1 #a084e8\n"
"    );\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 10px;\n"
"    padding: 10px 20px;\n"
"    font-family: 'Poppins', sans-serif;\n"
"    font-size: 15px;\n"
"    font-weight: 600;\n"
"    letter-spacing: 0.5px;\n"
"    box-shadow: 0px 4px 10px rgba(108, 99, 255, 0.3);\n"
"    transition: all 0.3s ease-in-out;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: qlineargradient(\n"
"        x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #8c78ff, stop:1 #b49aff\n"
"    );\n"
"    box-shadow: 0px 6px 15px rgba(108, 99, 255, 0.5);\n"
"    transform: scale(1.03);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #5c4aff;\n"
"    box-shadow: 0px 3px 6px rgba(108, 99, 255, 0.2);\n"
"    transform: scale(0.98);\n"
"}\n"
""));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(480, 60, 621, 81));
        label->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font: 800 28pt \"Poppins\", \"Segoe UI\", sans-serif;\n"
"    color: #1d1d1d;\n"
"    padding: 18px 25px;\n"
"    border-radius: 18px;\n"
"    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,\n"
"        stop:0 #ffffff, stop:1 #e0defa);\n"
"    border: 3px solid #6c63ff;\n"
"    qproperty-alignment: AlignCenter;\n"
"    letter-spacing: 3px;\n"
"    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.25);\n"
"}\n"
""));
        TeacherMainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(TeacherMainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1229, 25));
        TeacherMainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(TeacherMainWindow);
        statusbar->setObjectName("statusbar");
        TeacherMainWindow->setStatusBar(statusbar);

        retranslateUi(TeacherMainWindow);

        QMetaObject::connectSlotsByName(TeacherMainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *TeacherMainWindow)
    {
        TeacherMainWindow->setWindowTitle(QCoreApplication::translate("TeacherMainWindow", "Teacher Dashboard", nullptr));
        makeQuizButton->setText(QCoreApplication::translate("TeacherMainWindow", "MAKE QUIZ", nullptr));
        viewQuizzesButton->setText(QCoreApplication::translate("TeacherMainWindow", "VIEW QUIZZES", nullptr));
        reviewAttemptsButton->setText(QCoreApplication::translate("TeacherMainWindow", "REVIEW ATTEMPTS", nullptr));
        viewProfileButton->setText(QCoreApplication::translate("TeacherMainWindow", "VIEW PROFILE", nullptr));
        logoutButton->setText(QCoreApplication::translate("TeacherMainWindow", "LOGOUT", nullptr));
        label->setText(QCoreApplication::translate("TeacherMainWindow", "TEACHER DASHBOARD", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TeacherMainWindow: public Ui_TeacherMainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEACHERMAINWINDOW_H
